---
navigation:
  title: Primeiros Passos
  icon: auroral:glacial_basin
  parent: index.md
  position: 11
---

# <Color id="gold">Primeiros Passos</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="glacial_basin" scale="2" />

  Sua primeira aurora, sua primeira bacia, seu primeiro lingote de Aço Cintilante. O ciclo inteiro em cinco passos curtos.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Colete Pétalas Congeladas</Color>
</Column>

<ItemLink id="frozen_petals" /> são a chave para desbloquear o resto do mod. Fontes:

* Colhidas de <ItemLink id="aurora_bloom" />s que surgem naturalmente na neve durante auroras.
* Derrubadas por Náutilos Aurorais durante auroras.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Fabrique a Bacia Glacial</Color>
</Column>

<Row>
  <ItemImage id="glacial_basin" />
  ### <Color id="aqua">Bacia Glacial</Color>
</Row>

A Bacia Glacial é sua estação de trabalho principal. Coloque-a do lado de fora durante uma aurora para enchê-la de Aura Líquida.

<RecipeFor id="glacial_basin" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Seu Primeiro Aço Cintilante</Color>
</Column>

Quando sua Bacia Glacial tiver coletado Aura Líquida:

1. Clique com o botão direito na bacia segurando um Lingote de Ferro.
2. O ferro se transforma em <ItemLink id="shimmersteel_ingot" />.
3. Use Aço Cintilante para fabricar ferramentas e armas aprimoradas.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Suporte de Poções Frio</Color>
</Column>

<Row>
  <ItemImage id="cold_brewing_stand" />
  ### <Color id="aqua">Suporte de Poções Frio</Color>
</Row>

Um caminho sem Nether para poções. Usa bolas de neve como combustível em vez de Pó de Blaze.

<RecipeFor id="cold_brewing_stand" />

<Row>
  <ItemImage id="frozen_petals" />
  ### <Color id="aqua">Poções Estranhas sem Vara do Nether</Color>
</Row>

Pétalas Congeladas preparam uma Poção Estranha a partir de uma Garrafa de Água, exatamente como a Vara do Nether. A árvore inteira de poções se abre sem nunca pisar no Nether.
