---
item_ids:
  - auroral:shimmerweave_skates
navigation:
  title: Patins de Trama Cintilante
  icon: auroral:shimmerweave_skates
  parent: index.md
  position: 54
---

# <Color id="gold">Patins de Trama Cintilante</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="shimmerweave_skates" scale="2" />

  A peça mais versátil da armadura de Trama Cintilante. Mestres do gelo, da neve, da água e até da lava — transformando terreno hostil numa rodovia.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="shimmerweave_skates" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Velocidade no Gelo e na Neve</Color>
</Column>

<Row>
  <ItemImage id="shimmerweave_skates" />
  ### <Color id="aqua">Impulso de Superfície</Color>
</Row>

* Bônus de velocidade ao ficar sobre blocos de gelo ou neve.
* Velocidade extra em gelo compactado e gelo azul.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Embalo de Patinação no Gelo</Color>
</Column>

<Row>
  <ItemImage id="shimmerweave_skates" />
  ### <Color id="aqua">Deslize como um Barco</Color>
</Row>

* Ganhe embalo no gelo como um barco faz.
* Continue se movendo para acelerar; solte as teclas para deslizar.
* Gelo azul é a superfície de patinação mais lisa.
* O embalo continua mesmo sem teclas de movimento pressionadas.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Aprimoramento de Andar no Gelo</Color>
</Column>

<Row>
  <ItemImage id="shimmerweave_skates" />
  ### <Color id="aqua">Água e Lava Cedem</Color>
</Row>

* Cria gelo fosco ao andar sobre água.
* Converte **lava em obsidiana** ao contato.
* Lava abaixo de você durante uma queda vira obsidiana antes de você pousar.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Imunidade a Queda</Color>
</Column>

* Sem dano de queda ao pousar em gelo ou obsidiana.
* Perfeito para patinar descendo de alturas.
* Pule em direção à lava e pouse em obsidiana fresca.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Sinergia</Color>
</Column>

* <ItemLink id="shimmerweave_leggings" /> — velocidade adicional na neve e na areia das almas.
* **Pá de Aço Cintilante** — crie caminhos de neve rapidamente com Toque Suave.
* A conversão de lava em obsidiana torna a travessia do Nether muito mais segura.
