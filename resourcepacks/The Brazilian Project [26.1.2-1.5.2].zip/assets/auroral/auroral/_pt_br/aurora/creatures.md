---
item_ids:
  - auroral:auroral_nautilus_spawn_egg
navigation:
  title: Criaturas da Aurora
  icon: auroral:auroral_nautilus_spawn_egg
  parent: index.md
  position: 21
---

# <Color id="gold">Criaturas da Aurora</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="auroral_nautilus_spawn_egg" scale="2" />

  Seres atraídos pela luz celestial. Alguns você domestica, alguns você monta, alguns você simplesmente acaricia.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Náutilo Auroral</Color>
</Column>

<Row>
  <ItemImage id="auroral_nautilus_spawn_egg" />
  ### <Color id="aqua">Comportamento Selvagem</Color>
</Row>

Uma criatura flutuante pacífica que só aparece durante auroras, à deriva pelo céu com uma concha suavemente brilhante.

* Surge apenas durante auroras ativas
* Flutua suavemente em padrões circulares
* Pacífica e não hostil
* Vem em três tamanhos
* Desaparece graciosamente 30 segundos após o fim da aurora

<Row>
  <ItemImage id="aurora_shard" />
  ### <Color id="aqua">Atraindo Náutilos</Color>
</Row>

Náutilos selvagens são curiosos e derivam em direção a jogadores segurando um <ItemLink id="aurora_shard" />.

<Row>
  <ItemImage id="aurora_shard" />
  ### <Color id="aqua">Domando</Color>
</Row>

Alimente um Náutilo selvagem com um Fragmento da Aurora. Cada fragmento tem **33% de chance** de domar. Uma vez domado:

* O náutilo orbitará lentamente ao seu redor.
* Ele não desaparece mais quando a aurora termina.
* Partículas de coração confirmam o vínculo.

<Row>
  <ItemImage id="auroral_nautilus_spawn_egg" />
  ### <Color id="aqua">Comandando</Color>
</Row>

* **Shift + Botão direito** — alterna entre **Seguir** (orbita você) e **Ficar** (paira no lugar).
* Náutilos próximos no modo Seguir viajam com você entre dimensões. Náutilos no modo Ficar permanecem onde você os deixou.

<Row>
  <ItemImage id="auroral_nautilus_spawn_egg" />
  ### <Color id="aqua">Montando</Color>
</Row>

Náutilos domados podem ser montados sem sela.

1. Clique com o botão direito para montar (apenas o dono, o náutilo não pode estar no modo Ficar).
2. Controle o voo com as teclas de movimento e a direção do olhar.
3. Segure **Espaço** para carregar, solte para um impulso de velocidade de até **3x** quando totalmente carregado.

<Row>
  <ItemImage id="auroral_nautilus_spawn_egg" />
  ### <Color id="aqua">Armadura de Náutilo</Color>
</Row>

Náutilos Aurorais podem usar armaduras de náutilo vanilla (Cobre, Ferro, Ouro, Diamante, Netherita). Clique com o botão direito no náutilo domado segurando uma peça na mão principal para equipá-la. Clique com o botão direito com **tesoura** (sem agachar) para remover a armadura — a peça sai e a tesoura sofre 1 de dano de durabilidade.

<Row>
  <ItemImage id="aurora_shard" />
  ### <Color id="aqua">Drops</Color>
</Row>

Quando um jogador mata um Náutilo, ele pode derrubar:

* 1–2 Couros
* Um Fragmento de Prismarinho (5% de chance)
* Cascos de Náutilo (15% de chance, apenas abates por jogador)

<Row>
  <ItemImage id="roasted_snowball" />
  ### <Color id="aqua">Ofendendo os Náutilos</Color>
</Row>

Comer uma <ItemLink id="roasted_snowball" /> ofende a Aurora. Enquanto você carregar essa ofensa, Náutilos selvagens **não surgirão perto de você** durante auroras. Apenas Náutilos domados permanecem. Para se redimir, fabrique e coma uma <ItemLink id="sugared_roasted_snowball" /> e os céus o agraciarão novamente.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Snowlette Auroral</Color>
</Column>

<Row>
  <ItemImage id="auroral_snowlette_spawn_egg" />
  ### <Color id="aqua">Um Golem de Neve de Bolso</Color>
</Row>

Um companheiro pequeno e amigável criado ao clicar com o botão direito num Golem de Neve com um <ItemLink id="aurora_shard" />.

* Segue o jogador como um mascote
* Cerca de 1/4 do tamanho de um Golem de Neve normal
* Cura-se quando você joga bolas de neve nele
* Emite suaves faíscas de aurora
