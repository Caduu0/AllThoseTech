---
navigation:
  title: Fundição de Ligas
  icon: ftbic:alloy_smelter
  parent: machines/index.md
  position: 14
item_ids:
  - ftbic:alloy_smelter
---

# <Color id="gold">Fundição de Ligas</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="alloy_smelter" scale="2" />

  Máquina de ligas com três entradas. Combina lingotes em metais compostos (bronze, eletro, invar, constantan, aço, endério, netherita, liga avançada) sem o desvio de pós-e-moldes.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="alloy_smelter" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Espaços e a Regra de Entrada Única</Color>
</Column>

A Fundição de Ligas tem **três espaços de entrada** e **um espaço de saída**. Cada espaço de entrada comporta um ingrediente de qualquer quantidade; as quantidades da receita são comparadas à contagem da pilha do espaço, não divididas entre espaços.

Os espaços impõem uma **restrição de item único**: uma vez que um tipo de item está num espaço, os outros dois rejeitam o mesmo item. Isso evita dividir acidentalmente uma pilha entre espaços e deixar órfã uma receita que precisava de `2 ouro` num só lugar. Coloque 4 lingotes de ouro no espaço 1, não 2 no espaço 1 e 2 no espaço 2.

Quando as entradas podem corresponder a mais de uma receita, a fundição prefere a receita com **mais ingredientes**. Preencha os três espaços e você sempre obterá a liga de 3 entradas em vez de um subconjunto de 2.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Receitas de Liga</Color>
</Column>

<Row>
  <ItemImage id="bronze_ingot" />
  ### <Color id="aqua">Bronze</Color>
</Row>

3 cobre + 1 estanho → 4 lingotes de bronze.

<Row>
  <ItemImage id="electrum_ingot" />
  ### <Color id="aqua">Eletro</Color>
</Row>

1 prata + 1 ouro → 2 lingotes de eletro.

<Row>
  <ItemImage id="invar_ingot" />
  ### <Color id="aqua">Invar</Color>
</Row>

2 ferro + 1 níquel → 3 lingotes de invar.

<Row>
  <ItemImage id="constantan_ingot" />
  ### <Color id="aqua">Constantan</Color>
</Row>

1 cobre + 1 níquel → 2 lingotes de constantan.

<Row>
  <ItemImage id="steel_ingot" />
  ### <Color id="aqua">Aço</Color>
</Row>

1 <ItemLink id="industrial_grade_metal" /> + 1 carvão **ou** 1 carvão vegetal → 1 lingote de aço. O aço é o material de entrada para a liga avançada. Veja as receitas de <ItemLink id="advanced_alloy" /> abaixo.

<Row>
  <ItemImage id="minecraft:netherite_ingot" />
  ### <Color id="aqua">Netherita</Color>
</Row>

2 ouro + 2 fragmentos de netherita → 1 lingote de netherita. Pula completamente a etapa de ferraria vanilla de diamante+lingote de netherita.

<Row>
  <ItemImage id="enderium_ingot" />
  ### <Color id="aqua">Endério</Color>
</Row>

3 chumbo + 1 pó de diamante + 2 pérolas de ender → 2 lingotes de endério. A única forma de fazer lingotes de endério: não existe receita de fabricação com formato.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Liga Avançada</Color>
</Column>

A Fundição de Ligas produz <ItemLink id="advanced_alloy" /> por três receitas baseadas em aço. **Aço é obrigatório em todos os caminhos**. Produza-o primeiro ligando metal de qualidade industrial com carvão ou carvão vegetal.

* 1 aço + 2 bronze + 1 alumínio → 1 liga avançada
* 1 aço + 1 eletro + 1 alumínio → 1 liga avançada
* 1 aço + 2 invar + 1 alumínio → 1 liga avançada

<RecipesFor id="advanced_alloy" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Estatísticas</Color>
</Column>

* **Nível:** MV (entrada de Média Voltagem)
* **Amortecedor de energia:** <Energy config="machines.alloy_smelter_capacity" />
* **Consumo de energia:** <Energy config="machines.alloy_smelter_use" rate="true" /> (três vezes o da <ItemLink id="advanced_powered_furnace" />)
* **Ciclo padrão:** 200 tiques por receita (modificável com <ItemLink id="overclocker_upgrade" />)

<ItemImage id="minecraft:air" scale="0.25"/>
