---
navigation:
  title: Máquinas
  icon: ftbic:macerator
  position: 30
---

# <Color id="gold">Máquinas</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="macerator" scale="2" />

  As máquinas de processamento de receitas do FTBIC compartilham um inventário, um ciclo de receitas por tique, um amortecedor de energia e até quatro espaços de **melhoria**. Variantes avançadas têm amortecedores maiores e maior rendimento. Máquinas utilitárias como o Alimentador de Lotes têm seus próprios controles.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Estrutura das Máquinas</Color>
</Column>

Máquinas de processamento de receitas compartilham:

* **Amortecedor de energia**: exibido à direita da GUI
* **Barra de progresso**: enche conforme a receita progride; padrão de 200 tiques/receita
* **Espaços de melhoria**: instale <ItemLink id="overclocker_upgrade" />, <ItemLink id="energy_storage_upgrade" />, <ItemLink id="transformer_upgrade" /> ou <ItemLink id="ejector_upgrade" />
* **[Configuração de Lados](side_configuration.md)**: faces independentes de item, fluido e energia pelo botão E/S
* **[Travas de Espaço de Entrada](side_configuration.md)**: atribuições fantasmas persistentes pelo botão L

Todas as máquinas LV são construídas em volta do invólucro <ItemLink id="machine_block" /> mais um núcleo específico da receita (por exemplo, <ItemLink id="electronic_circuit" /> mais sílex e pedra para o Macerador).

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Subseções</Color>
</Column>

<SubPages icons={true} />
