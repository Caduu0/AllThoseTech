---
navigation:
  title: Máquina de Enlatar
  icon: ftbic:canning_machine
  parent: machines/index.md
  position: 8
item_ids:
  - ftbic:canning_machine
  - ftbic:advanced_canning_machine
  - ftbic:empty_can
  - ftbic:canned_food
---

# <Color id="gold">Máquina de Enlatar</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="canning_machine" scale="2" />

  Empacota comida em <ItemLink id="canned_food" /> para armazenamento eficiente, enche latas de tinta spray com corante e monta cartuchos de <ItemLink id="uranium_fuel_rod" />.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="canning_machine" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Row>
  <ItemImage id="empty_can" />
  ### <Color id="aqua">Lata Vazia</Color>
</Row>

Estampada de chapas de estanho. O recipiente de toda receita enlatada.

<RecipeFor id="empty_can" />

<Row>
  <ItemImage id="canned_food" />
  ### <Color id="aqua">Comida Enlatada</Color>
</Row>

Aceita qualquer item de comida mais uma lata vazia. As variantes enlatadas empilham mais e preservam a nutrição completa do original.
Comer comida enlatada devolve uma lata vazia.

<Row>
  <ItemImage id="light_spray_paint_can" />
  ### <Color id="aqua">Latas de Tinta Spray</Color>
</Row>

Encha uma <ItemLink id="empty_can" /> com qualquer corante para fazer uma <ItemLink id="light_spray_paint_can" /> ou <ItemLink id="dark_spray_paint_can" />. Veja [Tinta Spray](../utilities/spray_paint.md).

<ItemImage id="minecraft:air" scale="0.25"/>

**Estatísticas:** nível LV, amortecedor de <Energy config="machines.canning_machine_capacity" />, consumo de <Energy config="machines.canning_machine_use" rate="true" />.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Row>
  <ItemImage id="advanced_canning_machine" />
  ### <Color id="aqua">Máquina de Enlatar Avançada</Color>
</Row>

Nível MV. <Energy config="machines.advanced_canning_machine_use" rate="true" />, amortecedor de <Energy config="machines.advanced_canning_machine_capacity" />. Mesmas receitas e velocidade, e aceita <ItemLink id="parallel_processing_upgrade" />s.

<RecipeFor id="advanced_canning_machine" />
