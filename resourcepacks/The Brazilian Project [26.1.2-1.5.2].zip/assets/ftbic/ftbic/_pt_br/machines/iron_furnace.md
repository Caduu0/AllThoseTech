---
navigation:
  title: Fornalha de Ferro
  icon: ftbic:iron_furnace
  parent: machines/index.md
  position: 1
item_ids:
  - ftbic:iron_furnace
---

# <Color id="gold">Fornalha de Ferro</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="iron_furnace" scale="2" />

  Uma fornalha não elétrica que extrai **12 itens por carvão**, 50% a mais que o vanilla.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="iron_furnace" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

* Usa qualquer combustível de fornalha do vanilla.
* Existe especificamente para cobrir a lacuna antes da eletricidade. Assim que você tiver a <ItemLink id="powered_furnace" />, a Fornalha de Ferro fica obsoleta. Não precisa de energia nem de progressão.
* Não aceita melhorias.

Arraste um item do **JEI** para o espaço de entrada ou de combustível para definir um filtro fantasma persistente. Fantasmas não criam itens. Com o cursor vazio, clique com o botão direito num fantasma vazio, ou Shift+botão direito num espaço travado e preenchido, para remover o filtro. A correspondência inclui dados do item, e funis também obedecem a esses filtros.
