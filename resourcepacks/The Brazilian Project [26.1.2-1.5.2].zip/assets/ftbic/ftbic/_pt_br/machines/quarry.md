---
navigation:
  title: Pedreira
  icon: ftbic:quarry
  parent: machines/index.md
  position: 12
item_ids:
  - ftbic:quarry
  - ftbic:landmark
---

# <Color id="gold">Pedreira</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="quarry" scale="2" />

  Mina uma região retangular definida por um par de postes <ItemLink id="landmark" />. Despeja no inventário interno; extraia com um funil ou ejetor.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="quarry" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Instalação</Color>
</Column>

1. Coloque dois postes <ItemLink id="landmark" /> em cantos opostos da área que você quer minerar.
2. Coloque a Pedreira adjacente a um deles.
3. Alimente-a com energia HV. Ela começa a minerar para baixo.
4. 8 tiques para minerar um bloco, 2 tiques para mover a cabeça. Fluidos são substituídos por <ItemLink id="exfluid" /> para evitar vazamentos.

<ItemImage id="minecraft:air" scale="0.25"/>

**Estatísticas:** nível HV, amortecedor de <Energy config="machines.quarry_capacity" />, consumo de <Energy config="machines.quarry_use" rate="true" />.

A Pedreira é uma das poucas máquinas sem variante avançada. Em vez disso, use <ItemLink id="overclocker_upgrade" />s para acelerá-la.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Espaço de Picareta</Color>
</Column>

A Pedreira tem um espaço de picareta entre o botão de pausa e o espaço de bateria. Qualquer item com a tag `#minecraft:pickaxes` serve. Quando uma picareta está nesse espaço, a Pedreira simula minerar cada bloco com ela, então todo encantamento da picareta se aplica aos drops resultantes:

- <ItemLink id="minecraft:diamond_pickaxe" /> com **Toque Suave** solta pedra, minérios brutos, vidro e geradores intactos.
- <ItemLink id="minecraft:diamond_pickaxe" /> com **Fortuna III** multiplica drops de gemas, redstone e lápis-lazúli da mesma forma que um jogador faria.
- **Eficiência** concede um bônus de velocidade de mineração de 10% por nível, acumulando multiplicativamente com <ItemLink id="overclocker_upgrade" />s. Eficiência V torna a Pedreira 1,5 vez mais rápida pela mesma energia por tique, então cada bloco custa um terço a menos de energia.
- Outros encantamentos como Inquebrável não têm efeito. A Pedreira não depende de durabilidade de ferramenta.

Por padrão a picareta nunca sofre dano de durabilidade. Para espelhar o comportamento vanilla em que cada bloco minerado custa um de durabilidade, defina `quarry_pickaxe_takes_damage = true` em `ftbic-common.toml`. Se a picareta quebrar, o espaço esvazia e a mineração volta à tabela de drops sem ferramenta.

## Mineração seletiva

Instale uma <ItemLink id="quarry_filter_upgrade" /> para fazer a Pedreira minerar blocos selecionados. Abra o botão **F** ao lado da tela da Pedreira para configurá-la.

* Os nove espaços de bloco selecionam tipos de bloco posicionados. Clique num espaço com um bloco no cursor, ou arraste um bloco do JEI. Clique com o botão direito ou Shift+clique num espaço para limpá-lo.
* Insira até três IDs de **tag de bloco**, como `c:ores/iron`, e pressione Enter. Use tags de bloco em vez de tags de item; a Pedreira testa o bloco antes de minerá-lo.
* **Lista-branca** minera blocos correspondentes, enquanto **lista-negra** os exclui. Sem entradas, qualquer um dos modos deixa a seleção de blocos irrestrita.
* **Só minérios** restringe a mineração a blocos em `#c:ores`. Combina com o modo e as entradas selecionados.

O filtro atua sobre blocos no mundo, então uma picareta de Toque Suave ou Fortuna não altera quais blocos correspondem. A Pedreira procura sob pedra indesejada para alcançar um minério correspondente sem quebrar a pedra. Colunas sem blocos correspondentes são puladas sem usar energia. Depois de verificar a área inteira sem correspondências, ela pausa. Adicione ou mude uma regra e despause para varrer de novo.

A Melhoria de Filtro de Pedreira é limitada a uma por Pedreira. Suas configurações de filtro ficam salvas quando a melhoria é removida, mas a filtragem só fica ativa enquanto a melhoria estiver instalada. Cartões de Configuração copiam essas configurações para outra Pedreira; o destino também precisa de sua própria melhoria.

<RecipeFor id="quarry_filter_upgrade" />
