---
navigation:
  title: Macerador
  icon: ftbic:macerator
  parent: machines/index.md
  position: 3
item_ids:
  - ftbic:macerator
  - ftbic:advanced_macerator
---

# <Color id="gold">Macerador</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="macerator" scale="2" />

  Inicia a [cadeia de refino de minérios](ore_refining.md): blocos de minério suportados viram **3 minérios brutos**, cada minério bruto vira **2 minérios triturados**, e cada bloco de minério bruto vira **18 minérios triturados**. Também tritura lingotes em pó e pedregulho em areia.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="macerator" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Por Que Importa</Color>
</Column>

* Blocos de minério suportados rendem **3 minérios brutos**, depois **6 minérios triturados**. Lave e centrifugue para **15 lingotes**.
* Lingotes → 1 pó (para reciclagem ou processamento em cadeia).
* Pedregulho → areia, cascalho → sílex, etc.

<RecipesFor id="ftbic:coal_dust" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Row>
  <ItemImage id="advanced_macerator" />
  ### <Color id="aqua">Macerador Avançado</Color>
</Row>

Versão MV: amortecedor de <Energy config="machines.advanced_macerator_capacity" />, <Energy config="machines.advanced_macerator_use" rate="true" />. Mesma velocidade de receita e aceita <ItemLink id="parallel_processing_upgrade" />s.

<RecipeFor id="advanced_macerator" />
