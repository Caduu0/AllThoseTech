---
navigation:
  title: Configuração de Lados
  icon: ftbic:configuration_card
  parent: machines/index.md
  position: 1
item_ids:
  - ftbic:configuration_card
---

# <Color id="gold">Configuração de Lados</Color>

Use o botão **E/S** ao lado da tela de uma máquina para escolher quais faces podem transferir recursos. Selecione **Itens**, **Fluidos** ou **Energia**. Só aparecem os tipos de recurso suportados por aquela máquina, e o painel lembra sua última aba selecionada durante a sessão de jogo atual.

Os quadrados coloridos formam uma vista de **frente da máquina**: **Frente** fica no centro, **Cima** acima dele, **Baixo** abaixo, e **Esquerda** e **Direita** em cada lado. **Trás** é o quadrado separado no canto inferior esquerdo. Cada quadrado mostra o nome da face e o símbolo do modo; a legenda explica as cores.

* **Clique esquerdo** numa face para avançar pelos modos disponíveis.
* **Clique direito** para retroceder.
* **Shift+clique** para restaurar só aquela face para **Padrão** do recurso selecionado.
* Passe o mouse sobre uma face para ver seu nome completo, direção no mundo e modo atual.

Você também pode usar Tab para focar uma face e Enter ou Espaço para avançar; Shift+Enter ou Shift+Espaço a restaura. Girar uma máquina gira suas configurações. Máquinas sem orientação usam o norte como frente.

## Modos

* **Padrão (*)** mantém as regras de transferência originais da máquina. Máquinas novas começam assim.
* **Entrada (+)** permite inserção em espaços ou tanques de entrada válidos.
* **Saída (-)** permite extração de espaços ou tanques de saída válidos.
* **Ambos (+/-)** permite entrada e saída onde a máquina suporta ambos.
* **Desativado (X)** bloqueia transferências do recurso selecionado por aquela face.

As configurações de item, fluido e energia são independentes. Desativar itens numa face ainda permite energia ali, a menos que você a desative também. O acesso manual ao inventário da máquina continua disponível.

**Restaurar Padrões** restaura todas as faces de todos os tipos de recurso. Máquinas em mundos existentes mantêm seu comportamento original até serem configuradas.

## Exemplo: Macerador

Configure a face de itens de **Cima** como **Entrada**, a face de itens de **Trás** como **Saída** e as demais faces de itens como **Desativado**. Alimente minério por cima e colete pó atrás da máquina. A energia pode entrar por uma face configurada separadamente.

Tubos e funis podem extrair de uma face de saída diretamente. Instale uma <ItemLink id="ftbic:ejector_upgrade" /> se quiser que a própria máquina empurre itens prontos para um inventário adjacente. O ejetor só usa faces que permitem saída de itens. A configuração de lados não adiciona puxada automática de entrada.

## Regras das Máquinas

As configurações de lados preservam as restrições de espaços da máquina, os limites de energia e as regras de conversão. Caixas de bateria têm por padrão saída na frente e entrada nas outras faces; você pode atribuir entrada, saída ou ambos a qualquer face. A textura da face segue o papel de saída selecionado. Transformadores mantêm sua entrada frontal<ZapMode>, e retificadores mantêm sua entrada frontal de FE</ZapMode>. As demais faces elétricas mantêm seus papéis existentes; podem ser desativadas individualmente.

As configurações de energia se aplicam a cabos FTBIC e a conexões FE de outros mods onde essas interfaces estiverem disponíveis. **Padrão** mantém o comportamento original do seu modo de compatibilidade de energia.

Uma bomba oferece saída de fluido; um gerador geotérmico oferece entrada de fluido. Em teletransportadores, a entrada de itens/fluidos enche o inventário/tanque de envio e a saída drena o inventário/tanque de recepção. As configurações de lados controlam o acesso local, enquanto o vínculo entre teletransportadores continua operando normalmente.

Câmaras de reator compartilham as configurações do seu reator, usando a face externa que está sendo acessada. Uma configuração da face de cima se aplica ao topo do reator e ao topo de cada câmara anexada. Espaços de componentes do reator ainda comportam um item cada. O Planejador de Reator não tem E/S de recursos físicos para configurar.

## Travas de Espaço de Entrada

Máquinas elétricas com espaços comuns de entrada de itens têm um botão **L** abaixo de **E/S**. Use-o para atribuir itens fantasma aos espaços de entrada:

* Pegue um item no cursor antes de abrir **L**, depois clique numa linha de entrada para atribuí-lo. O item não é consumido.
* Com o cursor vazio, clicar copia o item existente daquele espaço de entrada.
* Clique com o botão direito ou Shift+clique numa linha para destravá-la.

Você também pode **arrastar um item do JEI diretamente para um espaço de entrada da máquina**, ou para uma linha no painel **L**. Isso cria um filtro fantasma mesmo que você não tenha o item; ele nunca adiciona itens ao inventário. Espaços de saída e auxiliares de bateria, picareta e melhoria não são alvos. Isso também funciona nas nove entradas da Bancada de Trabalho Elétrica, em geradores, bombas, espaços de carregamento e no Construtor de Antimatéria.

A **Fornalha de Ferro** aceita fantasmas do JEI em seus espaços de entrada e de combustível. Com o cursor vazio, clique com o botão direito num fantasma vazio para limpá-lo, ou Shift+botão direito num espaço travado e preenchido. Esses filtros também restringem a inserção por funis.

Um espaço travado só aceita seu item atribuído com componentes de dados correspondentes. Ele lembra a atribuição quando o processamento esvazia o espaço; um item fantasma esmaecido e um marcador ciano indicam a trava. Conteúdos existentes não são removidos quando você muda uma trava, e você ainda pode retirá-los manualmente. As travas persistem após recarregar o mundo. Layouts de reator usam seus controles de projeto separados.

Isso é útil numa Fundição de Ligas: reserve uma entrada para cobre e outra para estanho. Use um [Alimentador de Lotes](batch_feeder.md) quando também precisar de quantidades exatas de ingredientes.

## Cartão de Configuração

<ItemImage id="ftbic:configuration_card" scale="2" />

<RecipeFor id="ftbic:configuration_card" />

* **Agachar+Usar** numa máquina elétrica ou Alimentador de Lotes copia suas configurações de lados, travas de entrada e padrão do Alimentador de Lotes (onde suportado) para o cartão, sobrescrevendo configurações anteriores.
* **Usar** noutra máquina do **mesmo tipo** aplica essas configurações.
* A tooltip identifica o tipo de máquina salvo. Aplicar as configurações mantém o cartão reutilizável.

Aplicar um cartão substitui as configurações suportadas do alvo, incluindo limpar travas ou entradas de lote que estavam vazias na origem. Ele não move conteúdo do inventário, energia, melhorias ou layouts de reator. Use uma [Planta de Reator](../nuclear/blueprint.md) para projetos de reator.
