---
navigation:
  title: Fornalha Elétrica
  icon: ftbic:powered_furnace
  parent: machines/index.md
  position: 2
item_ids:
  - ftbic:powered_furnace
  - ftbic:advanced_powered_furnace
---

# <Color id="gold">Fornalha Elétrica</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="powered_furnace" scale="2" />

  Uma fornalha elétrica que executa qualquer receita de fundição do vanilla. <Energy config="machines.powered_furnace_use" rate="true" />, amortecedor de <Energy config="machines.powered_furnace_capacity" />, nível LV.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="powered_furnace" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Row>
  <ItemImage id="advanced_powered_furnace" />
  ### <Color id="aqua">Fornalha Elétrica Avançada</Color>
</Row>

Versão MV com amortecedor de <Energy config="machines.advanced_powered_furnace_capacity" /> e rendimento de <Energy config="machines.advanced_powered_furnace_use" rate="true" />. Mesmas receitas e velocidade, e aceita <ItemLink id="parallel_processing_upgrade" />s.

<RecipeFor id="advanced_powered_furnace" />

Aceita todas as receitas de fundição do vanilla mais quaisquer receitas de fundição adicionadas por mods. Use com <ItemLink id="overclocker_upgrade" /> para aumentar ainda mais o rendimento.
