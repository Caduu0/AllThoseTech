---
navigation:
  title: Compressor
  icon: ftbic:compressor
  parent: machines/index.md
  position: 4
item_ids:
  - ftbic:compressor
  - ftbic:advanced_compressor
  - ftbic:protein_bar
---

# <Color id="gold">Compressor</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="compressor" scale="2" />

  Comprime materiais em formas mais densas: carbono em <ItemLink id="carbon_plate" />, chapas de cobre em <ItemLink id="dense_copper_plate" />, bolas de neve em gelo, pilhas de pó em gemas.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="compressor" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Receitas de Compressão Notáveis</Color>
</Column>

* <ItemLink id="carbon_fibers" /> → <ItemLink id="carbon_plate" />
* 9× chapas de cobre → <ItemLink id="dense_copper_plate" /> (usada no <ItemLink id="nuclear_reactor" />)
* <ItemLink id="industrial_grade_metal" /> (a partir de <ItemLink id="mixed_metal_blend" />)
* Bolas de neve → gelo
* Pó de diamante → diamante
* <ItemLink id="compressed_coal_ball" /> (etapa de 5 min rumo à reciclagem de diamante)
* <ItemLink id="protein_bar" /> a partir de Carne Bovina

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Row>
  <ItemImage id="advanced_compressor" />
  ### <Color id="aqua">Compressor Avançado</Color>
</Row>

Nível MV. <Energy config="machines.advanced_compressor_use" rate="true" />, amortecedor de <Energy config="machines.advanced_compressor_capacity" />. Mesmas receitas e velocidade, e aceita <ItemLink id="parallel_processing_upgrade" />s.

<RecipeFor id="advanced_compressor" />
