---
navigation:
  title: Bancada de Trabalho Elétrica
  icon: ftbic:powered_crafting_table
  parent: machines/index.md
  position: 10
item_ids:
  - ftbic:powered_crafting_table
---

# <Color id="gold">Bancada de Trabalho Elétrica</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="powered_crafting_table" scale="2" />

  Uma bancada de fabricação automática. Trave um padrão 3×3 e ela consome itens do inventário para produzir o resultado, gastando <ZapMode>1 zap</ZapMode><FEMode><Energy config="machines.powered_crafting_table_use" /></FEMode> por fabricação.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="powered_crafting_table" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

**Estatísticas:** nível LV, amortecedor de <Energy config="machines.powered_crafting_table_capacity" />, <ZapMode>1 zap</ZapMode><FEMode><Energy config="machines.powered_crafting_table_use" /></FEMode> por fabricação.

Posicione-a contra um funil de saída para canalizar componentes para dentro e itens fabricados para fora. Funciona com qualquer receita com ou sem formato do vanilla ou de mods.

Arraste itens do **JEI** para a grade de fabricação para atribuir [filtros de espaço de entrada](side_configuration.md), ou use o painel **L**. Esses fantasmas mantêm cada ingrediente atribuído depois que a fabricação consome os itens reais. Um Cartão de Configuração copia os filtros para outra Bancada de Trabalho Elétrica; os ingredientes reais ainda precisam ser fornecidos.
