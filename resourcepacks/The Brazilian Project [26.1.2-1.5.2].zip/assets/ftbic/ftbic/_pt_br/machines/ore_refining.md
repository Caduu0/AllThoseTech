---
navigation:
  title: Refino de Minérios
  icon: ftbic:ore_washer
  parent: machines/index.md
  position: 4
item_ids:
  - ftbic:ore_washer
  - ftbic:advanced_ore_washer
  - ftbic:crushed_ore
  - ftbic:washed_ore
  - ftbic:refined_concentrate
---

# Refino de Minérios

A linha completa produz **5 lingotes por minério bruto**, ou **15 lingotes por bloco de minério** para metais suportados. Fortuna afeta o minério bruto coletado antes do processamento. Datapacks podem alterar esses padrões.

## Linha de processamento

1. **Macerador:** 1 bloco de minério vira **3 minérios brutos**.
2. **Macerador:** 1 minério bruto vira **2 minérios triturados**.
3. **Lavador de Minérios:** **2 minérios triturados + 1.000 mB de água** viram **3 minérios lavados**.
4. **Centrífuga:** **3 minérios lavados** viram **5 concentrados refinados**.
5. **Qualquer fornalha:** 1 concentrado vira **1 lingote**.

Blocos de minério bruto também vão direto para o Macerador. Um bloco vira **18 minérios triturados**, o mesmo que triturar seus nove minérios brutos um a um.

Começando com um bloco de minério você obtém **3 brutos, 6 triturados, 9 lavados, 15 concentrados e 15 lingotes**. Lavar esse lote completo usa três baldes de água.

Minério triturado e minério lavado também podem ser fundidos diretamente, um item por lingote. Esses caminhos mais curtos rendem **2 lingotes por bruto** após triturar, ou **3 por bruto** após lavar. Lingotes e pós comuns não podem voltar à cadeia de refino.

## Lavador de Minérios

<RecipeFor id="ftbic:ore_washer" />

O lavador aceita energia LV e comporta **16.000 mB** em cada tanque. Suas receitas padrão usam o tanque de entrada esquerdo; o tanque direito suporta saídas de fluido em receitas personalizadas. Insira água com um balde, célula de fluido ou automação de fluidos. Configure as faces de fluido e item independentemente em **E/S**.

Por padrão ele usa **<Energy config="machines.ore_washer_use" rate="true" />** e leva **20 segundos** por lavagem, antes de melhorias. O macerador básico leva 10 segundos por operação de trituração, ou 90 segundos para um bloco de minério bruto; a centrífuga básica leva 30 segundos por lote de refino. A configuração de máquinas e as definições de materiais podem alterar esses valores.

O processamento espera por um lote completo de itens, fluido e energia suficientes e espaço para todas as saídas. Use um [Alimentador de Lotes](batch_feeder.md) para entregar dois minérios triturados com um balde de água juntos.

### Lavador de Minérios Avançado

<RecipeFor id="ftbic:advanced_ore_washer" />

Nível MV. <Energy config="machines.advanced_ore_washer_use" rate="true" />, amortecedor de <Energy config="machines.advanced_ore_washer_capacity" />. Mesmas receitas, velocidade e tanques do Lavador de Minérios, e aceita <ItemLink id="parallel_processing_upgrade" />s. Cada lavagem paralela precisa de seus próprios dois minérios triturados e 1.000 mB de água.

## Materiais e automação

O FTBIC descobre metais a partir de tags comuns de matéria-prima e lingote e valida sua relação de fundição. Uma tag de minério habilita a receita de minério-para-bruto, e uma tag de bloco de armazenamento de bruto habilita a trituração de blocos. Mapeamentos incompletos ou conflitantes precisam de uma definição de material do autor do pacote. Gemas e sistemas de processamento incomuns não são convertidos automaticamente em metais.

Cada material tem intermediários nomeados e coloridos separados. Materiais iguais empilham normalmente; materiais diferentes ficam separados. O JEI mostra as variantes detectadas e suas receitas. Arraste a variante exata para as travas de entrada das máquinas ou para os espaços fantasmas do Alimentador de Lotes.

As cores usam primeiro uma sobreposição de datapack, depois uma paleta de materiais conhecida, e a textura do lingote selecionado para metais desconhecidos. Recarregamentos de resourcepack atualizam as cores amostradas. O ID do material na tooltip distingue materiais de cores parecidas.

Definições de material podem adicionar até dois subprodutos de centrífuga. Receitas com três saídas de item distintas exigem a **Centrífuga Avançada**. A descoberta automática não fornece metais secundários supostos.
