---
navigation:
  title: Bomba
  icon: ftbic:pump
  parent: machines/index.md
  position: 11
item_ids:
  - ftbic:pump
  - ftbic:exfluid
---

# <Color id="gold">Bomba</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="pump" scale="2" />

  Uma mineradora de fluidos autoextensível. Desce um tubo reto para baixo, drena qualquer poça de lava, água ou fluido de mod que encontrar e armazena o resultado em seu tanque interno de 128 baldes.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="pump" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Operação</Color>
</Column>

* Coloque-a em cima de um bloco. A bomba estende um tubo para baixo através de ar e blocos substituíveis até atingir fluido.
* 40 tiques para minerar um bloco de fluido, 10 tiques para mover o tubo um passo para baixo.
* Por padrão, fluidos drenados são substituídos por <ItemLink id="exfluid" /> para evitar exploits de fonte infinita. Desative na config se preferir buracos vazios.
* Conecte máquinas ou <ItemLink id="fluid_cell" />s por tubos na lateral para exportar o fluido.

**Estatísticas:** nível HV, amortecedor de <Energy config="machines.pump_capacity" />, consumo de <Energy config="machines.pump_use" rate="true" />.
