---
navigation:
  title: Extrusora
  icon: ftbic:extruder
  parent: machines/index.md
  position: 5
item_ids:
  - ftbic:extruder
  - ftbic:advanced_extruder
---

# <Color id="gold">Extrusora</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="extruder" scale="2" />

  Molda metal em **lingotes**, **chapas** e **varas**. A fonte da cadeia de lingotes/chapas/varas em massa que alimenta a fabricação.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="extruder" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Categorias de Receita</Color>
</Column>

A Extrusora tem três modos de saída de receita, selecionados por receita:

* **Lingote**: 2 pós → 1 lingote
* **Chapa**: 1 lingote → 1 chapa
* **Vara**: 1 lingote → 2 varas

Todo metal registrado no FTB Materials tem as três receitas, a menos que desativado na config. Chapas e varas usadas na fabricação (engrenagens, fios, componentes de máquina) quase sempre vêm daqui.

<ItemImage id="minecraft:air" scale="0.25"/>

**Estatísticas:** nível LV, amortecedor de <Energy config="machines.extruder_capacity" />, consumo de <Energy config="machines.extruder_use" rate="true" />.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Row>
  <ItemImage id="advanced_extruder" />
  ### <Color id="aqua">Extrusora Avançada</Color>
</Row>

Nível MV. <Energy config="machines.advanced_extruder_use" rate="true" />, amortecedor de <Energy config="machines.advanced_extruder_capacity" />. Mesmas receitas e velocidade, e aceita <ItemLink id="parallel_processing_upgrade" />s.

<RecipeFor id="advanced_extruder" />
