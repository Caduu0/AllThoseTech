---
navigation:
  title: Laminadora
  icon: ftbic:roller
  parent: machines/index.md
  position: 6
item_ids:
  - ftbic:roller
  - ftbic:advanced_roller
---

# <Color id="gold">Laminadora</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="roller" scale="2" />

  Produz **chapas** laminando lingotes até achatá-los. Uma alternativa às receitas de chapa da <ItemLink id="extruder" />: mesmas entradas, mesmas saídas, máquina diferente.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="roller" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

**Estatísticas:** nível LV, amortecedor de <Energy config="machines.roller_capacity" />, consumo de <Energy config="machines.roller_use" rate="true" />.

A Laminadora existe para que você possa separar a produção de chapas da Extrusora e paralelizar, o que é útil quando você começar a consumir chapas de cobre para cabos.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Row>
  <ItemImage id="advanced_roller" />
  ### <Color id="aqua">Laminadora Avançada</Color>
</Row>

Nível MV. <Energy config="machines.advanced_roller_use" rate="true" />, amortecedor de <Energy config="machines.advanced_roller_capacity" />. Mesmas receitas e velocidade, e aceita <ItemLink id="parallel_processing_upgrade" />s.

<RecipeFor id="advanced_roller" />
