---
navigation:
  title: Construtor de Antimatéria
  icon: ftbic:antimatter_constructor
  parent: machines/index.md
  position: 13
item_ids:
  - ftbic:antimatter_constructor
  - ftbic:antimatter
  - ftbic:antimatter_crystal
---

# <Color id="gold">Construtor de Antimatéria</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="antimatter_constructor" scale="2" />

  A máquina de fim de jogo. Fabrica <ItemLink id="antimatter" /> e <ItemLink id="antimatter_crystal" />, os únicos materiais usados no <ItemLink id="quantum_helmet" /><ZapMode> e na linha do <ItemLink id="iv_rectifier" /></ZapMode>.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="antimatter_constructor" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Operação</Color>
</Column>

* **Nível:** IV
* **Amortecedor:** <Energy config="machines.antimatter_constructor_capacity" />
* Acumula lentamente combustível de antimatéria a partir de energia pura. Exige uma alimentação IV sustentada. Planeje um reator nuclear ou uma parede de <ItemLink id="ev_solar_panel" />s.
* Aceita itens de "impulso" (veja as receitas `antimatter_boost`) que multiplicam temporariamente a produção.

<ItemImage id="minecraft:air" scale="0.25"/>

<Row>
  <ItemImage id="antimatter_crystal" />
  ### <Color id="aqua">Cristal de Antimatéria</Color>
</Row>

Antimatéria comprimida: a forma de gema, usada diretamente em receitas de fim de jogo.

<RecipeFor id="antimatter_crystal" />
