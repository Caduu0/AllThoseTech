---
navigation:
  title: Reprocessador
  icon: ftbic:reprocessor
  parent: machines/index.md
  position: 9
item_ids:
  - ftbic:reprocessor
  - ftbic:scrap
  - ftbic:scrap_box
---

# <Color id="gold">Reprocessador</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="reprocessor" scale="2" />

  Transforma **qualquer item inútil** em <ItemLink id="scrap" />. Sucata é um combustível premium para o Gerador Básico e pode ser fabricada em <ItemLink id="scrap_box" /> para uma recompensa aleatória.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="reprocessor" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

* Entrada: pedregulho, terra, carne podre, gravetos ou qualquer coisa marcada como reciclável.
* Saída: ~12,5% de chance de sucata por operação (configurável).
* **Estatísticas:** nível MV, amortecedor de <Energy config="machines.reprocessor_capacity" />, consumo de <Energy config="machines.reprocessor_use" rate="true" />.

<ItemImage id="minecraft:air" scale="0.25"/>

<Row>
  <ItemImage id="scrap_box" />
  ### <Color id="aqua">Caixa de Sucata</Color>
</Row>

9 sucatas comprimem-se numa Caixa de Sucata. Use-a para soltar um item aleatório, variando de materiais comuns ao raro pó de irídio. Agache-se ao usar uma pilha para abrir todas as caixas de uma vez.

<RecipeFor id="scrap_box" />
