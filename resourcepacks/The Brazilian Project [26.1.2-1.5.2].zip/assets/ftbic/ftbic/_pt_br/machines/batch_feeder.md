---
navigation:
  title: Alimentador de Lotes
  icon: ftbic:batch_feeder
  parent: machines/index.md
  position: 2
item_ids:
  - ftbic:batch_feeder
---

# <Color id="gold">Alimentador de Lotes</Color>

<ItemImage id="ftbic:batch_feeder" scale="2" />

O Alimentador de Lotes envia conjuntos completos de ingredientes para o inventário diretamente à frente de sua saída. Ele não precisa de energia e tem nove espaços de amortecedor de itens, um **amortecedor de fluido de 16.000 mB**, três configurações de item fantasma e uma configuração de fluido fantasma. Os lotes podem conter itens, fluido ou ambos.

<RecipeFor id="ftbic:batch_feeder" />

## Configurar os itens

1. Posicione o alimentador com sua saída de três canais voltada para a máquina ou inventário de destino.
2. Pegue uma pilha de ingrediente do seu inventário e clique num espaço fantasma na coluna **Lote**. Isso copia o item, seus dados e sua quantidade sem consumir a pilha. Devolva a pilha real ao seu inventário ou ao **Amortecedor** do alimentador.
3. Com o cursor vazio, clique com o botão esquerdo num espaço fantasma para aumentar sua quantidade ou com o direito para diminuir. Shift+clique limpa a entrada. Cada entrada é limitada a uma pilha normal daquele item, até 64.
4. Encha o amortecedor manualmente ou insira ingredientes por qualquer face exceto a frontal usando tubos ou funis. Lados de entrada podem ser desativados em **E/S**.

Você também pode arrastar itens do **JEI** para os três espaços fantasmas. Isso copia o item e a quantidade exibidos sem criar itens reais.

Para bronze, configure **3 lingotes de cobre** e **1 lingote de estanho** e deixe a terceira entrada vazia. O alimentador espera até que ambos estejam disponíveis e o destino aceite os quatro itens.

## Configurar o fluido

O tanque alto à **esquerda** é o amortecedor de fluido real. Forneça fluido por qualquer face que não seja a frontal usando tubos, ou clique nesse tanque com um balde ou célula de fluido no cursor. Clicar com um recipiente vazio o drena. Você também pode usar um recipiente de fluido diretamente no bloco. O acesso manual ao tanque continua disponível quando os lados automáticos estão desativados.

O tanque alto à **direita**, ao lado das três configurações de item, é o ingrediente de fluido fantasma:

1. Pegue um balde cheio ou célula de fluido e clique no tanque fantasma para copiar seu fluido e quantidade. Isso não consome o recipiente nem coloca fluido no amortecedor.
2. Alternativamente, clique nele com o cursor vazio para copiar o fluido do amortecedor, inicialmente até **1.000 mB**.
3. Digite a quantidade exata em **Fluido mB** e pressione **Definir** ou **Enter**. Qualquer valor de **1 a 16.000 mB** é aceito. Digitar sozinho não altera o lote.
4. Clique com o botão direito ou Shift+clique no tanque fantasma para limpar o ingrediente de fluido.

Você também pode arrastar um **ingrediente de fluido do JEI**, balde cheio ou célula de fluido para o tanque fantasma. Use **Fluido mB** para ajustar a quantidade depois.

Para um lote só de fluido, deixe as três configurações de item vazias. Por exemplo, configure **1.000 mB de lava** para alimentar uma centrífuga. Para um lote misto, o destino deve aceitar tanto os itens quanto o fluido pela face conectada.

## Regras de transferência

O alimentador tenta um lote a cada **8 tiques**. Se algum ingrediente estiver faltando, ou o destino não puder aceitar o lote completo, **nenhum item se move**. A correspondência inclui componentes de dados de item e fluido. Entradas duplicadas contam para o mesmo total, então um ingrediente nunca é contado duas vezes do amortecedor.

Um sinal de redstone pausa a alimentação. Desativar **Frente → Itens** ou **Frente → Fluidos** impede lotes que contenham esse recurso. Configure a face conectada da máquina receptora para aceitar cada recurso necessário.

Tubos não conseguem extrair itens soltos ou fluido dos amortecedores; a entrega automática sempre ocorre pela operação de lote completo. Você pode remover itens manualmente e drenar o amortecedor de fluido com um recipiente. Se usar um baú intermediário, quaisquer transferências posteriores para fora dele são controladas por seus tubos ou funis.

O alimentador não tem espaços de melhoria. Suas configurações de lotes persistem após recarregar o mundo. Um <ItemLink id="ftbic:configuration_card" /> copia as atribuições de item e fluido, as quantidades e as configurações de lados para outro Alimentador de Lotes, sem copiar o conteúdo do amortecedor.

Use [travas de espaço de entrada](side_configuration.md) numa máquina de receitas receptora quando espaços específicos precisarem ficar atribuídos a ingredientes específicos.
