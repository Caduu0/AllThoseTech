---
navigation:
  title: Acelerador Hidropônico
  icon: ftbic:hydroponic_accelerator
  parent: machines/index.md
  position: 5
item_ids:
  - ftbic:hydroponic_accelerator
  - ftbic:advanced_hydroponic_accelerator
---

# Acelerador Hidropônico

<ItemImage id="hydroponic_accelerator" scale="2" float="right"/>

<RecipeFor id="hydroponic_accelerator" />

Coloque uma semente no espaço de **semente** e um bloco permitido no espaço de **solo**. O solo fica na máquina e nunca é consumido. Forneça água e energia para cultivar plantações. Quando uma receita devolve sua semente, a semente fica no espaço de semente e continua crescendo, e só as sementes extras vão para a saída, então uma semente basta para rodar a máquina indefinidamente. Os espaços de saída mantêm produto, sementes devolvidas e o subproduto opcional separados. A receita inicial de trigo aceita terra em velocidade normal ou musgo a **1,25× de velocidade**. O JEI lista as opções de solo e a velocidade de cada receita.

A máquina básica tem um par de cultivo e três espaços de saída. O tanque de água comporta 16.000 mB. Um ciclo de crescimento padrão usa 250 mB. Use **E/S** para configurar as faces de item, fluido e energia. O botão **L** trava os espaços de semente e solo a itens exatos; você também pode arrastar itens do JEI para esses espaços para definir travas fantasmas. Travas fantasmas são filtros e não fornecem ingredientes.

## Modo de mutação

Apenas o Acelerador Hidropônico Avançado pode alternar entre **Crescimento** e **Mutação**. Coloque uma semente progenitora em cada faixa de um cruzamento. Ambos os progenitores precisam de uma receita de crescimento válida para seus respectivos solos. O JEI mostra os cruzamentos disponíveis e sua chance de sucesso. Um cruzamento bem-sucedido consome um de cada progenitor e produz o item mutante listado. Um cruzamento fracassado devolve ambas as sementes progenitoras. De qualquer forma, a operação usa tempo, água e energia. A máquina espera se algum resultado possível não couber.

## Acelerador Hidropônico Avançado

<ItemImage id="advanced_hydroponic_accelerator" scale="2" float="right"/>

<RecipeFor id="advanced_hydroponic_accelerator" />

A máquina avançada tem **quatro pares independentes de semente e solo** e doze espaços de saída, agrupados como produto, sementes e subproduto para cada faixa. Cada par de entrada pode ter suas próprias travas fantasmas e plantação. Seu tanque de água comporta 32.000 mB. Cada faixa ativa consome energia separadamente, até quatro vezes o uso de uma faixa única. Ela também aceita <ItemLink id="parallel_processing_upgrade" />s: cada faixa então cultiva uma plantação por semente em seu espaço de semente no mesmo ciclo, até quatro, usando esse mesmo múltiplo de água e energia da faixa.

No modo Mutação, as faixas **1 + 2** e **3 + 4** formam dois cruzamentos independentes. Cada progenitor usa seu próprio solo. O solo mais lento determina a velocidade do cruzamento. Progenitores de cruzamentos fracassados voltam à saída de sementes de sua respectiva faixa. O modo, as travas e o progresso persistem quando o mundo é salvo.
