---
navigation:
  title: Centrífuga
  icon: ftbic:centrifuge
  parent: machines/index.md
  position: 7
item_ids:
  - ftbic:centrifuge
  - ftbic:advanced_centrifuge
---

# <Color id="gold">Centrífuga</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="centrifuge" scale="2" />

  Separa materiais em seus componentes. Extrai <ItemLink id="ftbic:silicon_gem" /> de quartzo ou areia, decompõe cascalho e sílex e cuida do processamento de slime/magma.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="centrifuge" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Receitas de Separação Notáveis</Color>
</Column>

* Quartzo ou areia → <ItemLink id="ftbic:silicon_gem" />
* Cascalho → sílex
* Pedra luminosa → pó de pedra luminosa
* Creme de Magma → bola de slime (+ chance de pó de blaze)
* Célula de Refrigeração Pequena a partir de varas de blaze e gelo

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Row>
  <ItemImage id="advanced_centrifuge" />
  ### <Color id="aqua">Centrífuga Avançada</Color>
</Row>

Nível MV. Executa receitas de separação na mesma velocidade por <Energy config="machines.advanced_centrifuge_use" rate="true" />, com amortecedor de <Energy config="machines.advanced_centrifuge_capacity" />. Ela tem **três espaços de saída de itens** e **um tanque de saída de fluido**. Receitas com três resultados de item exigem essa máquina.

<RecipeFor id="advanced_centrifuge" />

## Processamento de Fluidos

Ambas as centrífugas têm um **tanque de entrada de 16.000 mB** à esquerda e um **tanque de saída de 16.000 mB** separado à direita. Cada tanque comporta um fluido por vez.

Receitas de separação podem usar um item, um fluido ou ambos, e podem produzir itens, um fluido ou ambos. A Centrífuga comum tem dois espaços de saída de itens; a Centrífuga Avançada tem três. Ambas aceitam um ingrediente de item e um de fluido, e produzem no máximo um resultado de fluido por receita.

Use tubos de fluido ou um balde ou Célula de Fluido na máquina para transferir fluidos. Os recipientes enchem a partir do tanque de saída ou esvaziam no tanque de entrada. Escolha **Entrada**, **Saída** ou **Entrada/Saída** na aba de fluidos da [configuração de E/S](side_configuration.md) para controlar cada face. Passe o mouse sobre qualquer tanque para ver seu fluido e quantidade.

O processamento espera até que todas as entradas necessárias estejam disponíveis e todos os resultados de item e fluido caibam. Um tanque de saída cheio ou um fluido diferente já presente nele bloqueia o processamento. Receitas existentes só de itens funcionam com tanques vazios.

A **Centrífuga Avançada** separa **1.000 mB de lava** (um balde) em **2 <ItemLink id="ftbic:tin_nugget" />**, **1 <ItemLink id="minecraft:copper_nugget" />** e **25% de chance de 1 <ItemLink id="minecraft:gold_nugget" />**. Nenhuma entrada de item é necessária. Fabrique nove pepitas de estanho num lingote de estanho, ou divida um lingote de volta em nove pepitas.

## Refino de minérios

Processe **3 minérios lavados em 5 concentrados refinados**, depois funda cada concentrado num lingote. Veja [Refino de Minérios](ore_refining.md) para a cadeia completa e a automação.
