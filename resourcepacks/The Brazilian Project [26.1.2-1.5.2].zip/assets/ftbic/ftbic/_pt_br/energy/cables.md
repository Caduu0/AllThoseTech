---
navigation:
  title: Cabos
  icon: ftbic:mv_cable
  parent: energy/index.md
  position: 1
item_ids:
  - ftbic:lv_cable
  - ftbic:mv_cable
  - ftbic:hv_cable
  - ftbic:ev_cable
  - ftbic:iv_cable
  - ftbic:superconducting_cable
  - ftbic:burnt_cable
  - ftbic:lv_reinforced_cable
  - ftbic:mv_reinforced_cable
  - ftbic:hv_reinforced_cable
  - ftbic:ev_reinforced_cable
  - ftbic:iv_reinforced_cable
  - ftbic:burnt_reinforced_cable
---

# <Color id="gold">Cabos</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="hv_cable" scale="2" />

  Cabos conectam produtores, consumidores e baterias numa única rede. A energia viaja instantaneamente por uma cadeia conectada até o **comprimento máximo de cabo** configurado (padrão 300).
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Row>
  <ItemImage id="lv_cable" />
  ### <Color id="aqua">Cabo LV (<Energy config="energy.lv_transfer_rate" rate="true" />)</Color>
</Row>

Cobre revestido de borracha. O cabo padrão para geradores básicos, o macerador e a fornalha elétrica.

<RecipeFor id="lv_cable" />

<ItemImage id="minecraft:air" scale="0.25"/>

<Row>
  <ItemImage id="mv_cable" />
  ### <Color id="aqua">Cabo MV (<Energy config="energy.mv_transfer_rate" rate="true" />)</Color>
</Row>

Fio de ouro isolado. Usado entre transformadores MV e máquinas de nível médio.

<RecipeFor id="mv_cable" />

<ItemImage id="minecraft:air" scale="0.25"/>

<Row>
  <ItemImage id="hv_cable" />
  ### <Color id="aqua">Cabo HV (<Energy config="energy.hv_transfer_rate" rate="true" />)</Color>
</Row>

Fio de ferro isolado. Necessário para máquinas avançadas e o primeiro estágio de saída de um reator nuclear.

<RecipeFor id="hv_cable" />

<ItemImage id="minecraft:air" scale="0.25"/>

<Row>
  <ItemImage id="ev_cable" />
  ### <Color id="aqua">Cabo EV (<Energy config="energy.ev_transfer_rate" rate="true" />)</Color>
</Row>

Fio de irídio isolado. Alimenta o Teletransportador, o Construtor de Antimatéria e as plataformas de carga do conjunto Quantum.

<RecipeFor id="ev_cable" />

<ItemImage id="minecraft:air" scale="0.25"/>

<Row>
  <ItemImage id="iv_cable" />
  ### <Color id="aqua">Cabo IV (<Energy config="energy.iv_transfer_rate" rate="true" />)</Color>
</Row>

Cabo de vidro para projetos de reator de alta saída e a cadeia de antimatéria de fim de jogo.

<RecipeFor id="iv_cable" />

<ItemImage id="minecraft:air" scale="0.25"/>

<Row>
  <ItemImage id="superconducting_cable" />
  ### <Color id="aqua">Cabo Supercondutor (<EnergyUnit rate="true" /> Ilimitado)</Color>
</Row>

Combine **dois cabos IV de vidro**, **um pó de redstone** e **um pó de pedra luminosa** em qualquer grade de fabricação para fazer **dois Cabos Supercondutores**.

Cabos supercondutores não têm limite de transferência e não podem queimar por sobrecarga. As máquinas ainda obedecem seus próprios limites de entrada e saída, e o comprimento máximo de cabo configurado ainda se aplica. Conecte cabos supercondutores uns aos outros; níveis de cabo diferentes não se conectam diretamente.

Um pulso ciano brilhante percorre o núcleo exposto enquanto a energia é transferida. Ele se apaga quando a fonte para de fornecer energia ou o destino se enche. Ramificações sem transferência aceita ficam escuras. O brilho funciona sem shaders.

<RecipeFor id="superconducting_cable" />

<ItemImage id="minecraft:air" scale="0.25"/>

<Row>
  <ItemImage id="burnt_cable" />
  ### <Color id="aqua">Cabo Queimado</Color>
</Row>

No que um cabo se transforma se receber voltagem demais. Quebre-o, substitua pelo nível correto e triture os restos queimados em <ItemLink id="scrap" />.

<RecipeFor id="scrap" fallbackText="Solte um Cabo Queimado em qualquer grade de fabricação para obter sucata." />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Cabos Reforçados</Color>

  <ItemImage id="lv_reinforced_cable" scale="2" />

  Um cubo inteiro com a resistência da <ItemLink id="reinforced_stone" /> que ainda conduz energia na taxa do seu nível. Use-os para passar cabos **através** de uma parede de contenção de reator sem deixar brecha. Cada nível pega a cor do cabo comum correspondente.
</Column>

Cabos reforçados conectam-se a cabos comuns do mesmo nível, então a transição na parede não precisa de transformador. Se um cabo reforçado for sobrecarregado, ele vira um <ItemLink id="burnt_reinforced_cable" /> (um bloco morto de pedra reforçada com núcleo chamuscado) em vez de um cabo queimado frágil, mantendo a contenção intacta.

<Row>
  <ItemImage id="lv_reinforced_cable" />
  ### <Color id="aqua">Cabo LV Reforçado (<Energy config="energy.lv_transfer_rate" rate="true" />)</Color>
</Row>

<RecipeFor id="lv_reinforced_cable" />

<Row>
  <ItemImage id="mv_reinforced_cable" />
  ### <Color id="aqua">Cabo MV Reforçado (<Energy config="energy.mv_transfer_rate" rate="true" />)</Color>
</Row>

<RecipeFor id="mv_reinforced_cable" />

<Row>
  <ItemImage id="hv_reinforced_cable" />
  ### <Color id="aqua">Cabo HV Reforçado (<Energy config="energy.hv_transfer_rate" rate="true" />)</Color>
</Row>

<RecipeFor id="hv_reinforced_cable" />

<Row>
  <ItemImage id="ev_reinforced_cable" />
  ### <Color id="aqua">Cabo EV Reforçado (<Energy config="energy.ev_transfer_rate" rate="true" />)</Color>
</Row>

<RecipeFor id="ev_reinforced_cable" />

<Row>
  <ItemImage id="iv_reinforced_cable" />
  ### <Color id="aqua">Cabo IV Reforçado (<Energy config="energy.iv_transfer_rate" rate="true" />)</Color>
</Row>

<RecipeFor id="iv_reinforced_cable" />

<Row>
  <ItemImage id="burnt_reinforced_cable" />
  ### <Color id="aqua">Cabo Reforçado Queimado</Color>
</Row>

No que um cabo reforçado se transforma quando sobrecarregado. Ele ainda é imune a Wither e ao dragão, então permanece no lugar como bloco de contenção, mas não conduz mais energia. Substitua-o por um cabo reforçado novo do nível correto.
