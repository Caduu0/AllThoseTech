---
navigation:
  title: Melhorias
  icon: ftbic:overclocker_upgrade
  position: 60
---

# <Color id="gold">Melhorias de Máquina</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="overclocker_upgrade" scale="2" />

  Máquinas que suportam melhorias têm 4 espaços de melhoria e aceitam **4 melhorias no total**, somadas entre todos os espaços e tipos. Um espaço pode comportar uma pilha de 4. Melhorias de Processamento Paralelo têm um limite separado de 3 por máquina. Shift+clique numa pilha na UI da máquina, ou agache+clique com o botão direito na máquina segurando melhorias para instalar quantas ela aceitar, até 4 de uma vez. Melhorias extras ficam na sua mão ou inventário.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Subseções</Color>
</Column>

<SubPages icons={true} />
