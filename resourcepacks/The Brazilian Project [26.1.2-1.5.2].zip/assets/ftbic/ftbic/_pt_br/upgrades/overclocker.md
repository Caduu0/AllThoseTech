---
navigation:
  title: Overclocker
  icon: ftbic:overclocker_upgrade
  parent: upgrades/index.md
  position: 1
item_ids:
  - ftbic:overclocker_upgrade
---

# <Color id="gold">Melhoria de Overclocker</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="overclocker_upgrade" scale="2" />

  Multiplica a velocidade de receita por **1,45×** e o uso de energia por **1,6×** por melhoria. A vazão escala exponencialmente com melhorias acumuladas, ao custo de um consumo de energia bem maior.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="overclocker_upgrade" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

* Tamanho máximo da pilha: **4 por espaço**, então um único espaço dá até 1,45⁴ ≈ 4,42× de velocidade por 1,6⁴ ≈ 6,55× de energia.
* Instale até 4 melhorias no total entre os espaços de melhoria da máquina. As 4 podem dividir um só espaço.
* Sempre acompanhe overclock pesado com uma <ItemLink id="transformer_upgrade" /> correspondente e cabeamento adequado.
