---
navigation:
  title: Melhoria de Transformador
  icon: ftbic:transformer_upgrade
  parent: upgrades/index.md
  position: 2
item_ids:
  - ftbic:transformer_upgrade
---

# <Color id="gold">Melhoria de Transformador</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="transformer_upgrade" scale="2" />

  Eleva o nível de voltagem aceito por uma máquina em **um** por melhoria. Um macerador LV com uma melhoria de transformador aceita entrada MV sem queimar.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="transformer_upgrade" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

Acumule até **4** para deixar qualquer máquina LV aceitar energia IV diretamente. Este é o companheiro clássico do overclock pesado, já que overclockers aumentam drasticamente o consumo além da capacidade de cabo do nível base.

Com todas as **4** instaladas, a máquina aceita qualquer quantidade de energia<ZapMode>, zaps ou FE,</ZapMode> e não pode mais queimar por sobrevoltagem.
