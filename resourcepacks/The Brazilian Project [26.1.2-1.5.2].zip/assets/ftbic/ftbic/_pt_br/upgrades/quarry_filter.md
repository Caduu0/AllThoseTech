---
navigation:
  title: Filtro de Pedreira
  icon: ftbic:quarry_filter_upgrade
  parent: upgrades/index.md
  position: 6
item_ids:
  - ftbic:quarry_filter_upgrade
---

# <Color id="gold">Melhoria de Filtro de Pedreira</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="quarry_filter_upgrade" scale="2" />

  Faz a <ItemLink id="quarry" /> minerar blocos selecionados enquanto deixa blocos indesejados no mundo.
</Column>

<RecipeFor id="quarry_filter_upgrade" />

Instale **uma** num espaço de melhoria da Pedreira. Abra o botão **F** ao lado da tela da Pedreira para selecionar amostras de blocos ou tags de bloco, escolher lista-branca ou lista-negra e, opcionalmente, ativar o modo só-minérios. Arraste itens de bloco do JEI para os espaços de amostra, ou clique com um item de bloco no cursor. Pressione Enter após digitar uma tag de bloco.

O modo só-minérios usa `#c:ores`. Blocos pulados não usam energia de mineração. Um Cartão de Configuração pode copiar as configurações do filtro para outra Pedreira. Veja a página da <ItemLink id="quarry" /> para detalhes.
