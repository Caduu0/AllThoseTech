---
navigation:
  title: Processamento Paralelo
  icon: ftbic:parallel_processing_upgrade
  parent: upgrades/index.md
  position: 5
item_ids:
  - ftbic:parallel_processing_upgrade
---

# <Color id="gold">Melhoria de Processamento Paralelo</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="parallel_processing_upgrade" scale="2" />

  Processa mais cópias de uma receita no mesmo ciclo. Cada melhoria adiciona **uma operação**, até **quatro operações** com três melhorias.
</Column>

<RecipeFor id="parallel_processing_upgrade" />

## Máquinas compatíveis

Instale esta melhoria na **Fornalha Elétrica Avançada**, **Macerador Avançado**, **Compressor Avançado**, **Centrífuga Avançada**, **Lavador de Minérios Avançado**, **Enlatadora Avançada**, **Laminadora Avançada**, **Extrusora Avançada**, **Acelerador Hidropônico Avançado**, **Fundição de Ligas** ou **Reprocessador**. O limite é de **três melhorias por máquina**, compartilhado entre seus espaços de melhoria. Processadores básicos e máquinas utilitárias não a aceitam.

## Como funcionam os lotes

* Todas as operações executam a **mesma receita** e compartilham uma barra de progresso. Um ciclo leva o tempo de processamento usual.
* No início de cada ciclo, a máquina escolhe tantas operações quanto seus ingredientes, espaço de saída e energia armazenada permitirem. Ela ainda pode rodar lotes menores.
* Toda operação precisa de um conjunto completo de ingredientes. Numa receita com vários ingredientes de item, mantenha cada ingrediente em seu próprio espaço de entrada, com itens suficientes para o lote.
* Lotes de centrífuga multiplicam quantidades de itens e fluidos. Cada operação rola saídas de chance independentemente. A máquina exige espaço para toda saída possível antes de prosseguir.
* No **Acelerador Hidropônico Avançado**, cada linha executa seu próprio lote. Uma linha roda uma operação por semente em seu espaço de sementes, até o limite da melhoria, e toda operação usa sua própria parcela de água. Cruzamentos de mutação precisam de uma semente parental de cada lado por operação.
* Ingredientes são consumidos quando o ciclo termina. Adicionar ingredientes durante um ciclo aumenta o próximo lote, sem aumentar o lote já em andamento.

O contador **executando / máximo** abaixo da seta de progresso mostra quantas operações estão rodando. Passe o mouse sobre ele para uma explicação. Uma máquina ociosa ou bloqueada mostra zero operações em execução.

## Energia e interrupções

Cada operação usa o custo de energia integral da máquina por tique. Quatro operações usam **quatro vezes a energia por tique**, com o mesmo custo de energia por receita de uma operação. Melhorias de <ItemLink id="overclocker_upgrade" /> ainda afetam tanto a velocidade quanto o custo de energia de cada operação.

Por exemplo, uma máquina usando **<Energy zaps="20" rate="true" />** usa **<Energy zaps="80" rate="true" />** enquanto processa quatro operações. Certifique-se de que seus cabos, fonte de energia e armazenamento aguentam.

Saídas bloqueadas pausam o ciclo sem usar energia. Ficar sem energia, perder ingredientes necessários, trocar de receita ou remover melhorias abaixo do tamanho do lote atual reinicia o progresso inacabado. Lotes inacabados não consomem ingredientes nem produzem saída. Salvar e carregar preserva o tamanho do lote e o progresso.
