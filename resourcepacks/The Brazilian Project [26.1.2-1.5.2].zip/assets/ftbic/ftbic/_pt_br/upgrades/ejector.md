---
navigation:
  title: Melhoria de Ejetor
  icon: ftbic:ejector_upgrade
  parent: upgrades/index.md
  position: 4
item_ids:
  - ftbic:ejector_upgrade
---

# <Color id="gold">Melhoria de Ejetor</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="ejector_upgrade" scale="2" />

  Empurra automaticamente itens prontos do espaço de saída da máquina para um inventário adjacente, por uma face que permita saída de itens.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="ejector_upgrade" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

* Escolha as faces de saída na [Configuração de Lados](../machines/side_configuration.md). Faces de itens só de entrada ou desativadas não ejetam.
* Combina bem com a <ItemLink id="powered_crafting_table" /> para construir cadeias de automação sem cadeias de funis.
* Uma melhoria de ejetor basta. Cópias adicionais não aceleram a saída.
