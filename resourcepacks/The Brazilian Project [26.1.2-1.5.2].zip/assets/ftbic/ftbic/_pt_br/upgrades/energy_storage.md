---
navigation:
  title: Melhoria de Armazenamento de Energia
  icon: ftbic:energy_storage_upgrade
  parent: upgrades/index.md
  position: 3
item_ids:
  - ftbic:energy_storage_upgrade
---

# <Color id="gold">Melhoria de Armazenamento de Energia</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="energy_storage_upgrade" scale="2" />

  Adiciona **<Energy config="machines.storage_upgrade" />** ao amortecedor interno de uma máquina por melhoria. Útil para suavizar cargas de trabalho irregulares ou para máquinas que precisam operar brevemente fora da rede.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="energy_storage_upgrade" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

Instale até **4** por máquina para um amortecedor local extra de <Energy config="machines.storage_upgrade" times="4" />.
