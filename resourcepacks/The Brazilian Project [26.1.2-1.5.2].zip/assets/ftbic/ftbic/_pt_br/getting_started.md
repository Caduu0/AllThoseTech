---
navigation:
  title: Primeiros Passos
  icon: ftbic:iron_furnace
  parent: index.md
  position: 1
---

# <Color id="gold">Primeiros Passos</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="iron_furnace" scale="2" />

  Sua entrada no FTB Industrial Contraptions começa com borracha, cobre e seu primeiro bloco de máquina.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Passo 1: Borracha</Color>
</Column>

Cace slimes (ou construa uma farm de slimes) e **funda** cada bola de slime para obter **8 borrachas**. Um punhado de bolas de slime é suficiente para cabear todo o início do jogo.

A borracha é usada em quase todos os cabos e máquinas do mod.

<ItemImage id="minecraft:air" scale="0.25"/>

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Passo 2: A Fornalha de Ferro</Color>
</Column>

Antes da eletricidade, funda com o dobro de eficiência com uma melhoria movida a combustível sobre o vanilla.

<Row>
  <ItemImage id="iron_furnace" />
  ### <Color id="aqua">Fornalha de Ferro</Color>
</Row>

<RecipeFor id="iron_furnace" />

Queima 1 carvão para **12 itens** (vs. 8 do vanilla). Um primeiro passo confiável enquanto você junta cobre e estanho.

<ItemImage id="minecraft:air" scale="0.25"/>

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Passo 3: Circuitos e o Bloco de Máquina</Color>
</Column>

<Row>
  <ItemImage id="machine_block" />
  ### <Color id="aqua">Bloco de Máquina</Color>
</Row>

O invólucro vazio usado na receita de fabricação de toda máquina de nível LV.

<RecipeFor id="machine_block" />

<Row>
  <ItemImage id="electronic_circuit" />
  ### <Color id="aqua">Circuito Eletrônico</Color>
</Row>

Fio de cobre mais redstone numa chapa de ferro. Necessário para quase todo dispositivo de nível LV.

<RecipeFor id="electronic_circuit" />

<ItemImage id="minecraft:air" scale="0.25"/>

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Passo 4: Primeira Energia</Color>
</Column>

Construa um <ItemLink id="basic_generator" />, conecte-o com <ItemLink id="lv_cable" /> a um <ItemLink id="macerator" /> ou <ItemLink id="powered_furnace" />, e você estará na era da energia.

<RecipeFor id="basic_generator" />

Macere cada minério bruto suportado em **2 minérios triturados**, depois funda-os para dois lingotes. Adicione um [Lavador de Minérios e uma Centrífuga](machines/ore_refining.md) para chegar a **5 lingotes por minério bruto**, ou **15 por bloco de minério**.

<ItemImage id="minecraft:air" scale="0.25"/>

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Progressão em Resumo</Color>
</Column>

1. **LV**: Gerador Básico, primeiras máquinas, Macerador, Fornalha Elétrica
2. **MV**: Painéis solares, cadeias de processamento de minérios (pós → chapas/engrenagens/varas)
3. **HV**: Máquinas avançadas, Compressor, Extrusora, Laminadora
4. **EV**: Reator nuclear, equipamentos Quantum, Teletransportador
5. **IV / fim de jogo**: Antimatéria, Élitro Mecânico, automação total

Leia a página [Rede de Energia](energy/index.md) a seguir para entender **níveis**, **voltagem** e o que acontece quando você alimenta energia demais num cabo de nível baixo.
