---
navigation:
  title: FTB Industrial Contraptions
  icon: ftbic:advanced_machine_block
  position: 0
---

# <Color id="gold">FTB Industrial Contraptions</Color>

<Column alignItems="center" fullWidth={true}>
  # <Color id="gold">FTB Industrial Contraptions</Color>

  <ItemImage id="advanced_machine_block" scale="2" />

  Um mod de tecnologia de geração de energia, processamento de minérios, engenharia nuclear e equipamentos de fim de jogo, construído em torno de uma rede de energia dedicada medida em **<EnergyUnit />**.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Comece Aqui</Color>
</Column>

* <ItemImage id="iron_furnace" scale="0.75"/> [Primeiros Passos](getting_started.md): seu primeiro bloco de máquina, primeiro gerador, primeiros cabos
* <ItemImage id="lv_cable" scale="0.75"/> [Rede de Energia](energy/index.md): <EnergyUnit />, níveis, cabeamento, armazenamento
* <ItemImage id="basic_generator" scale="0.75"/> [Geradores](generators/index.md): transformando combustível, calor, sol e vento em <EnergyUnit />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Conteúdo</Color>
</Column>

<ItemImage id="minecraft:air" scale="0.5"/>
<Row>
<Column>

* <ItemImage id="advanced_alloy" scale="0.75"/> [Materiais](materials/index.md)
* <ItemImage id="lv_cable" scale="0.75"/> [Rede de Energia](energy/index.md)
* <ItemImage id="basic_generator" scale="0.75"/> [Geradores](generators/index.md)
* <ItemImage id="macerator" scale="0.75"/> [Máquinas](machines/index.md)

</Column>
<Column>

* <ItemImage id="nuclear_reactor" scale="0.75"/> [Nuclear](nuclear/index.md)
* <ItemImage id="quantum_chestplate" scale="0.75"/> [Armadura Energizada](armor/index.md)
* <ItemImage id="overclocker_upgrade" scale="0.75"/> [Melhorias](upgrades/index.md)
* <ItemImage id="teleporter" scale="0.75"/> [Utilidades](utilities/index.md)

</Column>
</Row>
