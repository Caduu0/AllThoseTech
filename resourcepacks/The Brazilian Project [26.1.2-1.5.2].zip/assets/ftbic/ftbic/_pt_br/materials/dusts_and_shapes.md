---
navigation:
  title: Pós, Chapas, Varas
  icon: ftbic:dense_copper_plate
  parent: materials/index.md
  position: 1
item_ids:
  - ftbic:coal_dust
  - ftbic:charcoal_dust
  - ftbic:diamond_dust
  - ftbic:obsidian_dust
  - ftbic:dense_copper_plate
  - ftbic:copper_coil
  - ftbic:coal_ball
  - ftbic:compressed_coal_ball
  - ftbic:graphene
---

# <Color id="gold">Pós, Chapas e Formas</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="dense_copper_plate" scale="2" />

  Formas intermediárias que alimentam quase toda receita. Pós vêm do <ItemLink id="macerator" />; chapas da <ItemLink id="roller" /> ou da <ItemLink id="extruder" />; varas e engrenagens da cadeia da extrusora.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Pós Especiais</Color>
</Column>

<Row>
  <ItemImage id="ftbic:coal_dust" />
  ### <Color id="aqua">Pó de Carvão</Color>
</Row>

Carvão moído. Ingrediente de fabricação para fibras de carbono e bolas de carvão.

<RecipesFor id="ftbic:coal_dust" />

<Row>
  <ItemImage id="ftbic:charcoal_dust" />
  ### <Color id="aqua">Pó de Carvão Vegetal</Color>
</Row>

<Row>
  <ItemImage id="ftbic:obsidian_dust" />
  ### <Color id="aqua">Pó de Obsidiana</Color>
</Row>

<Row>
  <ItemImage id="ftbic:diamond_dust" />
  ### <Color id="aqua">Pó de Diamante</Color>
</Row>

Moa um diamante num macerador, comprima dois pós de volta num diamante, para um +100% de graça quando você quiser diamantes de equipamentos reciclados.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Chapas e Formas Especiais</Color>
</Column>

<Row>
  <ItemImage id="dense_copper_plate" />
  ### <Color id="aqua">Chapa de Cobre Densa</Color>
</Row>

9 chapas de cobre comprimidas em uma. Usada pela receita do <ItemLink id="nuclear_reactor" /> e por componentes avançados.

<Row>
  <ItemImage id="copper_coil" />
  ### <Color id="aqua">Bobina de Cobre</Color>
</Row>

Fio de cobre enrolado numa vara de ferro. Usada em geradores e transformadores.

<RecipeFor id="copper_coil" />

<Row>
  <ItemImage id="coal_ball" />
  ### <Color id="aqua">Bola de Carvão</Color>
</Row>

4 pós de carvão + 4 sílex → bola de carvão. Um degrau na escada de reciclagem de diamante.

<RecipeFor id="coal_ball" />

<Row>
  <ItemImage id="compressed_coal_ball" />
  ### <Color id="aqua">Bola de Carvão Comprimida</Color>
</Row>

Comprima 8 bolas de carvão. Alimenta etapas posteriores das receitas de diamante.

<Row>
  <ItemImage id="graphene" />
  ### <Color id="aqua">Grafeno</Color>
</Row>

Extrudado de carbono e silício. Usado em circuitos de fim de jogo.

<RecipeFor id="graphene" />
