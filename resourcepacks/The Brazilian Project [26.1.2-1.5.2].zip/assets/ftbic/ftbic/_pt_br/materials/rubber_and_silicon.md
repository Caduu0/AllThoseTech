---
navigation:
  title: Borracha e Silício
  icon: ftbic:rubber
  parent: materials/index.md
  position: 4
item_ids:
  - ftbic:rubber
  - ftbic:rubber_sheet
  - ftbic:silicon_gem
---

# <Color id="gold">Borracha e Silício</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="rubber" scale="2" />

  Os dois materiais em massa que você passará por quase toda máquina. Borracha envolve todo cabo; silício é a base de todo circuito.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Row>
  <ItemImage id="rubber" />
  ### <Color id="aqua">Borracha</Color>
</Row>

Funda uma **bola de slime** vanilla para obter **8 borrachas**. Esse é o principal caminho de produção. Farms de slime escalam sem esforço, e o rendimento de 8× por fundição mantém a fabricação de cabos barata.

<RecipesFor id="rubber" />

<Row>
  <ItemImage id="rubber_sheet" />
  ### <Color id="aqua">Chapa de Borracha</Color>
</Row>

9 borrachas → 1 chapa. Bloco decorativo e ingrediente de fabricação do <ItemLink id="mechanical_elytra" />.

<RecipeFor id="rubber_sheet" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Row>
  <ItemImage id="ftbic:silicon_gem" />
  ### <Color id="aqua">Silício</Color>
</Row>

O silício é fornecido pelo **FTB Materials**. Extraia-o de areia ou quartzo numa <ItemLink id="centrifuge" />. Todo circuito do mod começa com silício.
