---
navigation:
  title: Ligas
  icon: ftbic:iridium_alloy
  parent: materials/index.md
  position: 2
item_ids:
  - ftbic:mixed_metal_blend
  - ftbic:advanced_alloy
  - ftbic:industrial_grade_metal
  - ftbic:steel_ingot
  - ftbic:bronze_ingot
  - ftbic:electrum_ingot
  - ftbic:invar_ingot
  - ftbic:constantan_ingot
  - ftbic:iridium_alloy
  - ftbic:machine_block
  - ftbic:advanced_machine_block
  - ftbic:enderium_ingot
  - ftbic:enderium_nugget
  - ftbic:enderium_plate
  - ftbic:enderium_rod
  - ftbic:enderium_gear
  - ftbic:enderium_wire
  - ftbic:enderium_block
---

# <Color id="gold">Ligas</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="iridium_alloy" scale="2" />

  Metais compostos combinam vários lingotes em novos materiais de nível alto. A <ItemLink id="alloy_smelter" /> é a peça central: toda liga metálica passa por ela.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Ligas de Base</Color>
</Column>

Feitas na <ItemLink id="alloy_smelter" /> a partir de lingotes brutos. Cada uma pode ser macerada de volta em pó e refundida para recuperação.

<Row>
  <ItemImage id="bronze_ingot" />
  ### <Color id="aqua">Bronze</Color>
</Row>

3 cobre + 1 estanho → 4 bronzes. Liga de nível médio usada no caminho de bronze da liga avançada.

<RecipeFor id="bronze_ingot" />

<Row>
  <ItemImage id="electrum_ingot" />
  ### <Color id="aqua">Eletro</Color>
</Row>

1 prata + 1 ouro → 2 eletros. Usado no caminho de eletro da liga avançada e em cadeias de ligas condutoras.

<RecipeFor id="electrum_ingot" />

<Row>
  <ItemImage id="invar_ingot" />
  ### <Color id="aqua">Invar</Color>
</Row>

2 ferro + 1 níquel → 3 invars. Usado no caminho de invar da liga avançada e como intermediário resistente ao calor.

<RecipeFor id="invar_ingot" />

<Row>
  <ItemImage id="constantan_ingot" />
  ### <Color id="aqua">Constantan</Color>
</Row>

1 cobre + 1 níquel → 2 constantans. Liga intermediária de uso geral.

<RecipeFor id="constantan_ingot" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Aço: O Portal da Liga Avançada</Color>
</Column>

<Row>
  <ItemImage id="steel_ingot" />
  ### <Color id="aqua">Lingote de Aço</Color>
</Row>

A liga mais importante da cadeia: **toda receita de liga avançada começa com aço.** Feito na <ItemLink id="alloy_smelter" /> ligando <ItemLink id="industrial_grade_metal" /> com carbono:

* 1 metal de qualidade industrial + 1 carvão → 1 lingote de aço
* 1 metal de qualidade industrial + 1 carvão vegetal → 1 lingote de aço

<RecipesFor id="steel_ingot" />

Estoque aço antes de encarar o <ItemLink id="advanced_machine_block" />, a <ItemLink id="reactor_plating" /> ou qualquer máquina HV+, já que cada um exige liga avançada como ingrediente a jusante.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Mistura de Metais e Metal de Qualidade Industrial</Color>
</Column>

<Row>
  <ItemImage id="mixed_metal_blend" />
  ### <Color id="aqua">Mistura de Metais</Color>
</Row>

Recuperada macerando <ItemLink id="advanced_alloy" /> de volta numa mistura que pode ser refundida em liga avançada. Não existe fabricação com formato para a mistura. As receitas da fundição de ligas pulam essa etapa por completo.

<RecipesFor id="mixed_metal_blend" />

<Row>
  <ItemImage id="industrial_grade_metal" />
  ### <Color id="aqua">Metal de Qualidade Industrial</Color>
</Row>

Ferro comprimido: três lingotes de ferro comprimidos em um. Alimenta o <ItemLink id="machine_block" /> e é o ingrediente primário do aço.

<RecipeFor id="industrial_grade_metal" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Liga Avançada</Color>
</Column>

<Row>
  <ItemImage id="advanced_alloy" />
  ### <Color id="aqua">Liga Avançada</Color>
</Row>

A pedra fundamental de toda máquina de fim de jogo, peça de armadura, componente de reator e da <ItemLink id="iridium_alloy" />. Feita na <ItemLink id="alloy_smelter" /> por uma de três receitas baseadas em aço:

* 1 aço + 2 bronze + 1 alumínio → 1 liga avançada
* 1 aço + 1 eletro + 1 alumínio → 1 liga avançada
* 1 aço + 2 invar + 1 alumínio → 1 liga avançada

Escolha o caminho que combina com suas ligas disponíveis: bronze é a mais barata se você tiver cobre/estanho sobrando, invar gasta mais ferro bruto, eletro é a contagem de lingotes mais eficiente se você tiver prata e ouro para gastar.

<RecipesFor id="advanced_alloy" />

<Row>
  <ItemImage id="iridium_alloy" />
  ### <Color id="aqua">Liga de Irídio</Color>
</Row>

Chapas de irídio reforçadas com <ItemLink id="advanced_alloy" />. Liga de nível final, necessária para o <ItemLink id="iridium_circuit" />, o <ItemLink id="iridium_neutron_reflector" /> e o <ItemLink id="quantum_helmet" />.

<RecipeFor id="iridium_alloy" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Endério</Color>
</Column>

Liga mágica azul-arroxeada, usada no <ItemLink id="teleporter" />, no <ItemLink id="iv_cable" /> e em circuitos avançados.

<Row>
  <ItemImage id="enderium_ingot" />
  ### <Color id="aqua">Lingote de Endério</Color>
</Row>

Feito exclusivamente na <ItemLink id="alloy_smelter" />: 3 chumbo + 1 pó de diamante + 2 pérolas de ender → 2 lingotes de endério. Não existe caminho de fabricação com formato.

<Recipe id="ftbic:alloy_smelting/enderium_ingot" />

<RecipesFor id="enderium_ingot" fallbackText="Veja a Fundição de Ligas para a receita." />

<Row>
  <ItemImage id="enderium_block" />
  ### <Color id="aqua">Bloco de Endério</Color>
</Row>

9 lingotes → bloco. Armazenamento em massa.

<RecipeFor id="enderium_block" />

O endério existe em toda forma padrão: <ItemLink id="enderium_nugget" />, <ItemLink id="enderium_plate" />, <ItemLink id="enderium_rod" />, <ItemLink id="enderium_gear" />, <ItemLink id="enderium_wire" />.
