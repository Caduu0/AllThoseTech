---
navigation:
  title: Circuitos
  icon: ftbic:advanced_circuit
  parent: materials/index.md
  position: 5
item_ids:
  - ftbic:electronic_circuit
  - ftbic:advanced_circuit
  - ftbic:iridium_circuit
---

# <Color id="gold">Circuitos</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="advanced_circuit" scale="2" />

  Circuitos controlam o nível de cada máquina que você pode fabricar. Cada nível se constrói sobre o anterior.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Row>
  <ItemImage id="electronic_circuit" />
  ### <Color id="aqua">Circuito Eletrônico</Color>
</Row>

Fio de cobre + redstone sobre ferro. Libera o nível **LV** e é usado em toda máquina básica.

<RecipeFor id="electronic_circuit" />

<Row>
  <ItemImage id="advanced_circuit" />
  ### <Color id="aqua">Circuito Avançado</Color>
</Row>

Circuitos eletrônicos + pedra luminosa + <ItemLink id="enderium_ingot" />. Libera máquinas **HV/EV**: variantes avançadas, teletransportadores, o construtor de antimatéria.

<RecipeFor id="advanced_circuit" />

<Row>
  <ItemImage id="iridium_circuit" />
  ### <Color id="aqua">Circuito de Irídio</Color>
</Row>

Circuitos avançados + <ItemLink id="iridium_alloy" />. Libera **IV / fim de jogo**: equipamentos quantum e o nível final de cabo.

<RecipeFor id="iridium_circuit" />
