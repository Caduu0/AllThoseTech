---
navigation:
  title: Carbono
  icon: ftbic:carbon_plate
  parent: materials/index.md
  position: 3
item_ids:
  - ftbic:carbon_fibers
  - ftbic:carbon_fiber_mesh
  - ftbic:carbon_plate
---

# <Color id="gold">Peças de Carbono</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="carbon_plate" scale="2" />

  O material leve e absorvedor de energia por trás da armadura de <ItemLink id="carbon_helmet" />.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Row>
  <ItemImage id="carbon_fibers" />
  ### <Color id="aqua">Fibras de Carbono</Color>
</Row>

Fiadas de pó de carvão numa grade de fabricação.

<RecipeFor id="carbon_fibers" />

<Row>
  <ItemImage id="carbon_fiber_mesh" />
  ### <Color id="aqua">Malha de Fibra de Carbono</Color>
</Row>

Tecida a partir das fibras.

<RecipeFor id="carbon_fiber_mesh" />

<Row>
  <ItemImage id="carbon_plate" />
  ### <Color id="aqua">Chapa de Carbono</Color>
</Row>

Malha comprimida num <ItemLink id="compressor" />. A forma de qualidade de armadura.

<RecipeFor id="carbon_plate" />
