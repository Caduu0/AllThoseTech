---
navigation:
  title: Materiais
  icon: ftbic:advanced_alloy
  position: 5
---

# <Color id="gold">Materiais</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="advanced_alloy" scale="2" />

  O FTBIC usa o FTB Materials para minérios, lingotes, pepitas, pós, chapas, varas, engrenagens e fios. O mod adiciona um punhado de materiais especiais (ligas, peças de carbono, borracha, silício) mais a hierarquia de circuitos.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Subseções</Color>
</Column>

<SubPages icons={true} />
