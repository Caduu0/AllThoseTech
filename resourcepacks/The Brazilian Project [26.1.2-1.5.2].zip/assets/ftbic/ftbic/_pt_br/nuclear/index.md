---
navigation:
  title: Nuclear
  icon: ftbic:nuclear_reactor
  position: 40
---

# <Color id="gold">Energia Nuclear</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="nuclear_reactor" scale="2" />

  A fonte de energia de maior produção do mod, e o erro mais punitivo. Um reator funcionando produz **centenas a milhares de <EnergyUnit /> por tique**. Um falhando **vaporiza sua base**.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">As Três Variáveis</Color>
</Column>

Um layout de reator é um quebra-cabeça de três quantidades que interagem.

* <Color id="red">**Calor**</Color>: produzido pelas barras de combustível. Acumula no núcleo do reator.
* <Color id="aqua">**Refrigeração**</Color>: células de refrigeração e respiradouros puxam calor das barras de combustível adjacentes e o dispersam.
* <Color id="gold">**Produção**</Color>: <EnergyUnit /> por tique, multiplicado por refletores de nêutrons adjacentes e barras duplas/quádruplas.

Se o calor chegar a 100% o reator **explode**, escalando de um raio base de **10** até um limite de **80 blocos**, o suficiente para cavar uma cratera que chega à bedrock.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Subseções</Color>
</Column>

<SubPages icons={true} />
