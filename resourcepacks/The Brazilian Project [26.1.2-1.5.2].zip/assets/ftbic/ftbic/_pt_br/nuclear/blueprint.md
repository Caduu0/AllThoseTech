---
navigation:
  title: Planta de Reator
  icon: ftbic:reactor_blueprint
  parent: nuclear/index.md
  position: 11
item_ids:
  - ftbic:reactor_blueprint
---

# <Color id="gold">Planta de Reator</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="reactor_blueprint" scale="2" />

  Leve um layout testado do <ItemLink id="reactor_simulator" /> para um <ItemLink id="nuclear_reactor" />, ou dê uma cópia a outro jogador. Uma planta salva posições de componentes, a contagem de câmaras e a refrigeração de água planejada.
</Column>

<RecipeFor id="reactor_blueprint" />

## <Color id="gold">Gravar um Projeto</Color>

1. Monte e teste seu layout no [Simulador de Reator](simulator.md).
2. Mantenha uma **Planta de Reator em branco** no inventário e pressione **Escrever Planta** no planejador.
3. A planta escrita brilha e sua tooltip mostra as contagens salvas de câmaras e componentes.

Você também pode segurar uma planta em branco e **usá-la no bloco planejador** para copiar o layout atual dele. Para gravar outra cópia, use outra planta em branco. O botão só escreve em plantas em branco.

## <Color id="gold">Construir o Reator</Color>

1. Segure a planta escrita e **use-a no bloco do reator**. A GUI abre com seu layout salvo mostrado como itens fantasma.
2. Anexe as <ItemLink id="nuclear_reactor_chamber" />s necessárias. **Câmaras** e **Água** mostram primeiro as condições reais e depois as planejadas.
3. **Pause o reator e desative o controle por redstone.** Coloque os componentes necessários no seu inventário.
4. Pressione **Construir do Inventário**. Cada espaço vazio correspondente recebe um componente real do seu inventário.

A lista de materiais mostra quantas peças estão disponíveis e quantas ainda faltam, contando corretamente os componentes já instalados. Use as setas abaixo da lista para ver mais peças.

Peças faltantes ficam visíveis como fantasmas. Traga mais componentes e pressione **Construir do Inventário** de novo para terminar. **Bordas vermelhas** marcam peças conflitantes ou espaços planejados que precisam de mais câmaras. Remova peças conflitantes você mesmo; o preenchimento automático só ocupa espaços vazios.

Componentes usados mantêm seu **calor e desgaste** existentes. Uma planta salva o layout, não a condição dos itens simulados. Verifique a refrigeração planejada e confira as peças instaladas antes de ligar o reator.

**Limpar** remove a prévia e deixa os componentes reais no lugar.

## <Color id="gold">Reusar e Compartilhar</Color>

* **Carregar num planejador:** use uma planta escrita num bloco planejador. Pause uma simulação ativa antes.
* **Sobrescrever uma planta:** segure-a e **Agache+Use** no planejador para substituir o projeto salvo pelo layout atual.
* **Copiar uma prévia carregada:** mantenha uma planta em branco no inventário e pressione **Escrever Planta** na GUI do reator.
* **Compartilhar um projeto:** entregue a planta escrita a outro jogador. Usar uma planta não a consome.

## <Color id="gold">Predefinições e Projetos da Área de Transferência</Color>

O reator também pode carregar layouts diretamente. Escolha uma predefinição salva com as setas e pressione **Carregar Predefinição**, ou pressione **Exportar** no planejador e **Colar Projeto** no reator.

Ambos os caminhos usam a mesma prévia, lista de materiais e botão **Construir do Inventário**. Você pode então escrever esse projeto carregado numa planta em branco.
