---
navigation:
  title: Barras de Combustível
  icon: ftbic:uranium_fuel_rod
  parent: nuclear/index.md
  position: 2
item_ids:
  - ftbic:uranium_fuel_rod
  - ftbic:dual_uranium_fuel_rod
  - ftbic:quad_uranium_fuel_rod
---

# <Color id="gold">Barras de Combustível</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="quad_uranium_fuel_rod" scale="2" />

  Barras de combustível produzem **calor** e **produção**. Duplicar barras (dupla, quádrupla) aumenta ambos exponencialmente, ao custo de exigências de refrigeração bem mais pesadas.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Row>
  <ItemImage id="uranium_fuel_rod" />
  ### <Color id="aqua">Barra de Combustível de Urânio</Color>
</Row>

Fabricada numa <ItemLink id="canning_machine" /> a partir de urânio esgotado. Unidade base: 1× de produção, 1× de calor.

<RecipeFor id="uranium_fuel_rod" />

<Row>
  <ItemImage id="dual_uranium_fuel_rod" />
  ### <Color id="aqua">Barra de Combustível de Urânio Dupla</Color>
</Row>

Duas barras unidas. 4× de produção, 2× de calor (eficiente por célula, mas o dobro de carga de refrigeração).

<RecipeFor id="dual_uranium_fuel_rod" />

<Row>
  <ItemImage id="quad_uranium_fuel_rod" />
  ### <Color id="aqua">Barra de Combustível de Urânio Quádrupla</Color>
</Row>

O núcleo dos projetos de alta produção. 10× de produção, 4× de calor. Precisa de posicionamento cuidadoso ao lado de refrigeração pesada.

<RecipeFor id="quad_uranium_fuel_rod" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Regra de Posicionamento</Color>
</Column>

Uma barra emite calor/produção para cada um de seus **vizinhos válidos** (barra, refletor ou componente dissipador de calor). Espaços vazios não contam. Regra prática de projeto:

* Uma única barra com 4 refletores produz tanto quanto uma barra quádrupla com 2 refletores. Comece por aí.
* Escale para barras duplas/quádruplas só depois que sua refrigeração escalar.
