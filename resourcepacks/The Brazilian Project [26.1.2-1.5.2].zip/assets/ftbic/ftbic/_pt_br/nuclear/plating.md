---
navigation:
  title: Blindagem de Reator
  icon: ftbic:reactor_plating
  parent: nuclear/index.md
  position: 4
item_ids:
  - ftbic:reactor_plating
  - ftbic:heat_capacity_reactor_plating
  - ftbic:containment_reactor_plating
---

# <Color id="gold">Blindagem de Reator</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="reactor_plating" scale="2" />

  A blindagem modifica o **casco do reator** em si: sua capacidade total de calor e seu raio de explosão se o pior acontecer.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Row>
  <ItemImage id="reactor_plating" />
  ### <Color id="aqua">Blindagem de Reator</Color>
</Row>

Reduz o dano de explosão se o reator entrar em colapso.

<RecipeFor id="reactor_plating" />

<Row>
  <ItemImage id="heat_capacity_reactor_plating" />
  ### <Color id="aqua">Blindagem de Reator de Capacidade de Calor</Color>
</Row>

Aumenta o amortecedor de calor total do reator: mais lento para atingir o ponto crítico, mais fácil de operar projetos pulsados.

<RecipeFor id="heat_capacity_reactor_plating" />

<Row>
  <ItemImage id="containment_reactor_plating" />
  ### <Color id="aqua">Blindagem de Reator de Contenção</Color>
</Row>

Atenua fortemente a potência da explosão se a contenção falhar. A rede de segurança para projetos agressivos.

<RecipeFor id="containment_reactor_plating" />
