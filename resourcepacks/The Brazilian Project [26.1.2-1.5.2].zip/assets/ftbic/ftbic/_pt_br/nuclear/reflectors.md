---
navigation:
  title: Refletores de Nêutrons
  icon: ftbic:thick_neutron_reflector
  parent: nuclear/index.md
  position: 5
item_ids:
  - ftbic:neutron_reflector
  - ftbic:thick_neutron_reflector
  - ftbic:iridium_neutron_reflector
---

# <Color id="gold">Refletores de Nêutrons</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="iridium_neutron_reflector" scale="2" />

  Refletores contam como um **vizinho de barra válido** nos cálculos de produção: uma barra ao lado de um refletor se comporta como se houvesse outra barra ali. Cada refletor tem vida útil finita, exceto o de irídio.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Row>
  <ItemImage id="neutron_reflector" />
  ### <Color id="aqua">Refletor de Nêutrons</Color>
</Row>

Barato, de uso único. Gasta-se com o tempo.

<RecipeFor id="neutron_reflector" />

<Row>
  <ItemImage id="thick_neutron_reflector" />
  ### <Color id="aqua">Refletor de Nêutrons Grosso</Color>
</Row>

Vida útil mais longa. Padrão em projetos de meio de jogo.

<RecipeFor id="thick_neutron_reflector" />

<Row>
  <ItemImage id="iridium_neutron_reflector" />
  ### <Color id="aqua">Refletor de Nêutrons de Irídio</Color>
</Row>

Vida útil infinita. Caro, mas o padrão em todo projeto permanente.

<RecipeFor id="iridium_neutron_reflector" />
