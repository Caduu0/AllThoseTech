---
navigation:
  title: Reator Nuclear
  icon: ftbic:nuclear_reactor
  parent: nuclear/index.md
  position: 1
item_ids:
  - ftbic:nuclear_reactor
  - ftbic:nuclear_reactor_chamber
---

# <Color id="gold">Reator Nuclear</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="nuclear_reactor" scale="2" />

  O núcleo do reator tem **3 colunas de 6 espaços** (18 espaços). Anexe até **6 câmaras de reator**, uma em cada face, para expandi-lo a **9 colunas e 54 espaços**.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="nuclear_reactor" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Câmara do Reator</Color>
</Column>

Anexe uma câmara a qualquer face do reator para destravar mais uma coluna de **6 espaços de componentes**, até 9 colunas e 54 espaços com todas as seis câmaras. As câmaras também encaminham **energia** e **itens** para o reator central, então cabos e tubos de itens podem se conectar por uma câmara.

<RecipeFor id="nuclear_reactor_chamber" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Operação</Color>
</Column>

* **Nível:** a saída é EV por padrão; projetos máximos podem chegar ao território IV.
* **Amortecedor interno:** <Energy config="machines.nuclear_reactor_capacity" />.
* Abra a GUI e solte componentes na grade: barras de combustível, respiradouros de calor, células de refrigeração, refletores, blindagem.
* Alterne o reator com redstone. Sem sinal ele pausa, deixando você refrigerar entre pulsos.
* Jade / Top mostram o % de calor e a produção ao vivo.

Use [Plantas de Reator](blueprint.md) para carregar um layout planejado como espaços fantasmas e preenchê-lo do seu inventário com **Construir do Inventário**.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Refrigeração Ambiental</Color>
</Column>

O reator amostra cada face voltada para fora de seu casco e das câmaras anexadas uma vez por ciclo. Para cada face tocando um bloco de **água**, a refrigeração do casco do reator de cada <ItemLink id="heat_vent" /> / <ItemLink id="reactor_heat_vent" /> / <ItemLink id="overclocked_heat_vent" /> / <ItemLink id="advanced_heat_vent" /> interno recebe um bônus proporcional:

* 0 faces adjacentes à água → refrigeração **1×** (linha de base)
* Totalmente submerso → refrigeração **2×**

Truque barato: afunde o reator numa piscina rasa e sele o topo com vidro. Todo valor `reactorCool` dobra de graça. Água corrente ou parada contam; lava e ar não.

Cabos reforçados (e sua variante queimada) são tratados como faces **neutras**: são ignorados por completo no cálculo da proporção. Passar energia de um reator submerso por um cabo reforçado não diluirá seu bônus de água.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Contenção</Color>
</Column>

Reatores sempre explodem quando o calor chega a 100%. Cerque o reator com blocos resistentes a explosões (<ItemLink id="reinforced_stone" /> ou <ItemLink id="reinforced_glass" />) antes de insistir em projetos agressivos. A explosão escala de **raio base de 10 blocos** até um limite máximo de **80 blocos**, o suficiente para alcançar a bedrock.

Veja [Barras de Combustível](fuel_rods.md), [Refrigeração](cooling.md), [Refletores](reflectors.md) e [Blindagem](plating.md) para as peças que vão nos espaços.
