---
navigation:
  title: Componentes de Refrigeração
  icon: ftbic:heat_vent
  parent: nuclear/index.md
  position: 3
item_ids:
  - ftbic:small_coolant_cell
  - ftbic:medium_coolant_cell
  - ftbic:large_coolant_cell
  - ftbic:heat_vent
  - ftbic:reactor_heat_vent
  - ftbic:overclocked_heat_vent
  - ftbic:component_heat_vent
  - ftbic:advanced_heat_vent
  - ftbic:heat_exchanger
  - ftbic:reactor_heat_exchanger
  - ftbic:component_heat_exchanger
  - ftbic:advanced_heat_exchanger
---

# <Color id="gold">Componentes de Refrigeração</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="heat_vent" scale="2" />

  Dois tipos de refrigeração: **células** absorvem calor num amortecedor interno até saturar, e **respiradouros / trocadores** movem calor continuamente das barras → respiradouros → ar.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Células de Refrigeração</Color>
</Column>

Armazenam calor num amortecedor finito. Quando uma célula satura, ela para de absorver. Projetos que dependem só de células são projetos de **pulso** com tempo de inatividade planejado.

<Row>
  <ItemImage id="small_coolant_cell" />
  ### <Color id="aqua">Célula de Refrigeração Pequena</Color>
</Row>

<RecipeFor id="small_coolant_cell" />

<Row>
  <ItemImage id="medium_coolant_cell" />
  ### <Color id="aqua">Célula de Refrigeração Média</Color>
</Row>

<RecipeFor id="medium_coolant_cell" />

<Row>
  <ItemImage id="large_coolant_cell" />
  ### <Color id="aqua">Célula de Refrigeração Grande</Color>
</Row>

<RecipeFor id="large_coolant_cell" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Respiradouros de Calor</Color>
</Column>

Respiradouros dissipam calor do casco do reator ou de componentes vizinhos. Necessários para projetos **contínuos**.

<Row>
  <ItemImage id="heat_vent" />
  ### <Color id="aqua">Respiradouro de Calor</Color>
</Row>

Unidade base. Puxa calor do casco do reator e o ventila para o ar.

<RecipeFor id="heat_vent" />

<Row>
  <ItemImage id="reactor_heat_vent" />
  ### <Color id="aqua">Respiradouro de Calor de Reator</Color>
</Row>

Respiradouro de dissipação do casco mais forte. Puxa mais calor por tique da própria câmara do reator.

<RecipeFor id="reactor_heat_vent" />

<Row>
  <ItemImage id="component_heat_vent" />
  ### <Color id="aqua">Respiradouro de Calor de Componente</Color>
</Row>

Puxa calor de **componentes** adjacentes (células de refrigeração) em vez do casco. A peça-chave de projetos de reciclagem de células.

<RecipeFor id="component_heat_vent" />

<Row>
  <ItemImage id="overclocked_heat_vent" />
  ### <Color id="aqua">Respiradouro de Calor com Overclock</Color>
</Row>

Respiradouro híbrido: dissipa tanto para o casco quanto para os vizinhos. Sofre dano próprio sob carga pesada, mas é potente quando posicionado corretamente.

<RecipeFor id="overclocked_heat_vent" />

<Row>
  <ItemImage id="advanced_heat_vent" />
  ### <Color id="aqua">Respiradouro de Calor Avançado</Color>
</Row>

O respiradouro de fim de jogo. Usado em projetos de classe IV.

<RecipeFor id="advanced_heat_vent" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Trocadores de Calor</Color>
</Column>

Trocadores **equalizam** calor: movem calor de vizinhos mais quentes para os mais frios, ou do casco do reator para um componente. Sem trocadores, o calor fica concentrado ao redor das barras de combustível.

<Row>
  <ItemImage id="heat_exchanger" />
  ### <Color id="aqua">Trocador de Calor</Color>
</Row>

<RecipeFor id="heat_exchanger" />

<Row>
  <ItemImage id="reactor_heat_exchanger" />
  ### <Color id="aqua">Trocador de Calor de Reator</Color>
</Row>

Troca calor especificamente com o casco do reator. Puxa calor do casco para a grade de componentes, onde é dissipado pelos respiradouros.

<RecipeFor id="reactor_heat_exchanger" />

<Row>
  <ItemImage id="component_heat_exchanger" />
  ### <Color id="aqua">Trocador de Calor de Componente</Color>
</Row>

Só equilibra calor entre componentes adjacentes. Barato.

<RecipeFor id="component_heat_exchanger" />

<Row>
  <ItemImage id="advanced_heat_exchanger" />
  ### <Color id="aqua">Trocador de Calor Avançado</Color>
</Row>

Trocador de fim de jogo.

<RecipeFor id="advanced_heat_exchanger" />
