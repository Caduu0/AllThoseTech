---
navigation:
  title: Simulador de Reator
  icon: ftbic:reactor_simulator
  parent: nuclear/index.md
  position: 10
item_ids:
  - ftbic:reactor_simulator
---

# <Color id="gold">Simulador de Reator</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="reactor_simulator" scale="2" />

  Uma bancada de projeto para reatores nucleares. Solte componentes na grade, execute-os em até 1000x de velocidade e veja exatamente o quão quente o reator ficará antes de construir o de verdade no mundo.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Como usar</Color>
</Column>

1. Coloque o simulador e abra sua GUI.
2. Use o seletor de câmaras para escolher quantas câmaras de reator seu projeto real terá (0 a 6, o que destrava 3 a 9 colunas ativas).
3. Use o seletor de água para definir quanto do casco do reator ficará tocando água. Corresponde ao multiplicador de refrigeração ambiental do reator real.
4. Preencha a grade com componentes fantasma. Arraste itens do seletor de componentes ou do JEI para a grade. Clique com o botão direito num espaço para limpá-lo. Essas escolhas não consomem itens reais.
5. Clique em **Analisar** para um veredito rápido. O simulador executa a vida útil completa das barras de combustível numa cópia do seu projeto e informa **ESTÁVEL** ou **SUPERAQUECE @ ciclo N**.
6. Clique em **Iniciar** para rodar a simulação ao vivo. Use a fileira de velocidade para escolher 20x / 100x / 500x / 1000x. Os números atualizam ao vivo: energia atual por tique, energia acumulada e ciclos decorridos.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Controles</Color>
</Column>

* **Iniciar**: começa ou retoma a simulação.
* **Pausar**: congela no meio da execução. Os espaços voltam a ser editáveis. Os contadores da execução ficam onde estavam.
* **Reiniciar**: limpa todos os espaços e zera todos os contadores. O painel inteiro volta ao vazio.
* **Recomeçar**: executa o projeto atual de novo a partir do ciclo 0. Barras de combustível e células de refrigeração são reenchidas à durabilidade total.
* **Analisar**: executa a vida útil completa das barras de combustível como verificação em segundo plano, sem tocar nos contadores ao vivo.

Enquanto a simulação está ativa (rodando e não pausada), os espaços travam e os seletores de câmaras/água ficam desativados. Pause antes de editar.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Compartilhando projetos</Color>
</Column>

* **Exportar** copia uma descrição JSON do projeto atual para sua área de transferência. Cole no chat ou salve num arquivo de notas.
* **Importar** lê o JSON da sua área de transferência e o carrega no simulador.

Use uma [Planta de Reator](blueprint.md) para levar o layout a um reator de verdade ou compartilhá-lo com outro jogador. Mantenha uma planta em branco no inventário e pressione **Escrever Planta**. O reator também pode carregar uma predefinição salva com **Carregar Predefinição**, ou um layout exportado com **Colar Projeto**.

<ItemImage id="minecraft:air" scale="0.25"/>
***

O simulador não precisa de energia. Faça alguns. Compartilhe-os. Quando finalmente construir o de verdade na sua base, você já sabe como ele vai se comportar.
