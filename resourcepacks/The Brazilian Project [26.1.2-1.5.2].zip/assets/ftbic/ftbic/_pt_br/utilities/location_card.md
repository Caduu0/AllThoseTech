---
navigation:
  title: Cartão de Localização
  icon: ftbic:location_card
  parent: utilities/index.md
  position: 7
item_ids:
  - ftbic:location_card
---

# <Color id="gold">Cartão de Localização</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="location_card" scale="2" />

  Um atalho portátil para vincular <ItemLink id="teleporter" />s. Salve as coordenadas de um teletransportador no cartão, depois use o cartão para programar o destino de outro teletransportador, sem precisar rolar a lista de descoberta de pares.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="location_card" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Uso</Color>
</Column>

1. **Salve um destino.** Segure um Cartão de Localização vazio e clique com o botão direito num <ItemLink id="teleporter" />. O cartão armazena a dimensão, a posição e o nome daquele teletransportador.
2. **Programe um segundo teletransportador.** Segure o cartão vinculado e clique com o botão direito noutro teletransportador seu. O destino do teletransportador clicado passa a ser a posição salva no cartão.
3. **Limpe o cartão.** Agache+clique com o botão direito no ar para apagar o vínculo.

<ItemImage id="minecraft:air" scale="0.25"/>
***

Um cartão vinculado é **brilhante** (reluz como um item encantado) e mostra sua dimensão, coordenadas e nome de teletransportador salvos na tooltip. Útil para manter um cartão rotulado por base ou por hub de rede.
