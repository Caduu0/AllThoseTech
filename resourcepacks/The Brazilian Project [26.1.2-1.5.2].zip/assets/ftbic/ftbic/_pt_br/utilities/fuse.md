---
navigation:
  title: Fusível
  icon: ftbic:fuse
  parent: utilities/index.md
  position: 6
item_ids:
  - ftbic:fuse
---

# <Color id="gold">Fusível</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="fuse" scale="2" />

  Uma carga de reparo de uso único para **máquinas queimadas**. Clique com o botão direito numa máquina FTBIC queimada com um fusível na mão para restaurá-la.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="fuse" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

Máquinas queimam quando alimentadas com voltagem maior que a aceita. Veja [Transformadores](../energy/transformers.md) e as notas de queima na página da [Rede de Energia](../energy/index.md). Cabos queimados não são reparáveis; recicle-os em <ItemLink id="scrap" />.
