---
navigation:
  title: Teletransportador
  icon: ftbic:teleporter
  parent: utilities/index.md
  position: 1
item_ids:
  - ftbic:teleporter
---

# <Color id="gold">Teletransportador</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="teleporter" scale="2" />

  Uma plataforma de teletransporte para jogadores. Pareie dois teletransportadores por nome, alimente um com energia MV ou superior e fique sobre ele para saltar ao outro. Um par vinculado também funciona como tubo bidirecional de itens e fluidos (veja abaixo).
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Instalação</Color>
</Column>

1. Coloque um teletransportador e abra sua GUI.
2. Defina seu **ID** (o nome pelo qual outros teletransportadores o verão).
3. Escolha se deseja **publicá-lo**: teletransportadores públicos aparecem na lista de todos; os não publicados só aparecem para o dono.
4. Conecte **energia HV** em qualquer lado. O teletransportador é um nó HV completo: aceita entrada HV e também emite saída HV, então qualquer lado do par pode atuar como fonte ou consumidor de energia.
5. Na GUI de outro teletransportador, escolha o destino na lista. Escolher um destino vincula automaticamente a outra ponta de volta, desde que ela ainda não esteja apontada para outro lugar.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Custo de Energia</Color>
</Column>

* **Mínimo:** <Energy config="machines.teleporter_min_use" /> (distâncias de até 16 blocos).
* **Máximo:** <Energy config="machines.teleporter_max_use" /> (distâncias iguais ou acima de 1.200 blocos).
* Escala linearmente entre esses limites.

O chunk de destino **precisa estar carregado**. Se o alvo estiver longe, carregue-o previamente com um carregador de chunks ou o teletransporte falhará.

<ItemImage id="minecraft:air" scale="0.25"/>
***

Apenas o **dono** do teletransportador pode renomeá-lo, excluí-lo ou despublicá-lo.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Tubo de Itens e Fluidos</Color>
</Column>

Um par de teletransportadores vinculados também é um tubo bidirecional. Funis, tubos e bombas (qualquer coisa que possa empurrar itens ou fluidos para dentro de um bloco) funcionam em qualquer um dos teletransportadores. O que entra de um lado sai perto do outro.

Cada teletransportador tem dois amortecedores internos para cada tipo de recurso:

* **Armazenamento de envio**: 9 espaços + um tanque de fluido de 16.000 mB. Tubos, funis e dutos externos que empurram para dentro do teletransportador depositam seus recursos aqui.
* **Armazenamento de recepção**: 9 espaços + um tanque de fluido de 16.000 mB. Tubos externos que puxam do teletransportador extraem daqui.

A cada poucos tiques o teletransportador descarrega seu amortecedor de envio no amortecedor de recepção do par. Ambos os teletransportadores fazem isso, então o mesmo par transporta tráfego nas duas direções ao mesmo tempo. A vazão limita-se a aproximadamente 8 itens e 2.000 mB por descarga por lado.

Como tudo externo passa pelos dois amortecedores internos, qualquer tubo ou duto de mod que possa empurrar para dentro de um inventário alimenta o armazenamento de envio, e qualquer tubo ou duto que possa extrair de um inventário drena o armazenamento de recepção. Nenhuma integração especial de mod é necessária.

O modelo de item do teletransportador expõe o armazenamento de envio como espaços "só inserção" e o de recepção como espaços "só extração", então a detecção automática da maioria dos mods roteará corretamente sem configuração extra.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Energia de Transporte</Color>
</Column>

Mover recursos pelo vínculo custa um pequeno consumo ocioso no teletransportador **remetente** — não por item, mas uma vez por segundo enquanto há tráfego. Se nada se moveu no último segundo, o consumo para.

O par **compartilha energia a 100%**: a cada poucos tiques os dois amortecedores se rebalanceiam para o mesmo nível de carga, então alimentar energia num teletransportador a torna disponível nas duas pontas imediatamente. Qualquer teletransportador também pode **emitir HV** para uma rede de cabos conectada. Uma instalação comum: coloque um teletransportador ao lado dos seus geradores e outro ao lado das suas pedreiras ou máquinas, depois conecte o lado distante à sua rede de máquinas. A energia flui na direção necessária, mesmo entre dimensões.

Teletransportadores são filtrados das redes de envio um do outro, então colocar dois teletransportadores vinculados no mesmo trecho de cabo não causa vai-e-vem. O mecanismo de equilíbrio cuida da transferência do par e a rede de cabos cuida do resto.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Botões de Limpeza</Color>
</Column>

Se o par estiver inacessível (desvinculado, chunk do par descarregado, amortecedor cheio do outro lado), o conteúdo vai se acumular no armazenamento de envio. Dois botões na GUI lidam com isso:

* **Limpar Armazenamento** move tudo dos espaços de envio de itens para os espaços de recepção de itens no mesmo teletransportador, para que um tubo de extração comum no lado de recepção possa recuperá-los.
* **Limpar Fluidos** faz o mesmo para os tanques de fluido.

O bloco em si solta seu conteúdo de itens no mundo quando quebrado, então nada se perde se você recolher um teletransportador meio cheio.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Tubos entre Dimensões</Color>
</Column>

A transferência de itens e fluidos funciona entre dimensões, igual ao teletransporte de jogador. Enquanto uma transferência está ativa, o chunk do par é **carregado à força automaticamente**, então você não precisa de um carregador de chunks separado na outra ponta. O chunk é liberado após cerca de um minuto de tráfego ocioso.
