---
navigation:
  title: Marco
  icon: ftbic:landmark
  parent: utilities/index.md
  position: 2
item_ids:
  - ftbic:landmark
---

# <Color id="gold">Marco</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="landmark" scale="2" />

  Um poste marcador que define a área de trabalho da <ItemLink id="quarry" />. Coloque dois marcos em cantos opostos da região que você quer minerar.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="landmark" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

Clique com o botão direito num marco colocado para conectá-lo visualmente ao seu par. A pedreira minerará a região retangular delimitada pelos dois postes, até a bedrock.
