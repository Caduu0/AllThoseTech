---
navigation:
  title: Utilitários
  icon: ftbic:teleporter
  position: 70
---

# <Color id="gold">Utilitários e Curiosidades</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="teleporter" scale="2" />

  Tudo que não se encaixa em geradores, máquinas ou armaduras: teletransportadores, marcos, cargas nucleares, tinta spray, armazenamento de fluidos, fusíveis e caixas de sucata.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Subseções</Color>
</Column>

<SubPages icons={true} />
