---
navigation:
  title: Blocos Reforçados
  icon: ftbic:reinforced_stone
  parent: utilities/index.md
  position: 8
item_ids:
  - ftbic:reinforced_stone
  - ftbic:reinforced_glass
---

# <Color id="gold">Blocos Reforçados</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="reinforced_stone" scale="2" />

  Blocos de construção resistentes a explosões. A contenção ideal para um <ItemLink id="nuclear_reactor" /> e as paredes mais seguras para um campo de testes de explosivos.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Row>
  <ItemImage id="reinforced_stone" />
  ### <Color id="aqua">Pedra Reforçada</Color>
</Row>

<RecipeFor id="reinforced_stone" />

<Row>
  <ItemImage id="reinforced_glass" />
  ### <Color id="aqua">Vidro Reforçado</Color>
</Row>

Bloco reforçado transparente. Use-o como painel de observação para uma sala de reator.

<RecipeFor id="reinforced_glass" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

Precisa passar energia por uma parede de contenção sem quebrá-la? Veja a família de cabos reforçados na página de [Cabos](../energy/cables.md). Eles têm a mesma resistência e ainda conduzem na taxa do seu nível.
