---
navigation:
  title: Tinta Spray
  icon: ftbic:dark_spray_paint_can
  parent: utilities/index.md
  position: 5
item_ids:
  - ftbic:light_spray_paint_can
  - ftbic:dark_spray_paint_can
---

# <Color id="gold">Latas de Tinta Spray</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="dark_spray_paint_can" scale="2" />

  Item cosmético para retemar blocos de máquinas. Toda máquina FTBIC suporta um estado de pintura **claro** e um **escuro**.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Row>
  <ItemImage id="light_spray_paint_can" />
  ### <Color id="aqua">Lata de Tinta Spray (Clara)</Color>
</Row>

<Row>
  <ItemImage id="dark_spray_paint_can" />
  ### <Color id="aqua">Lata de Tinta Spray (Escura)</Color>
</Row>

Enchidas numa <ItemLink id="canning_machine" /> a partir de uma <ItemLink id="empty_can" /> e corante correspondente.

Clique com o botão direito em qualquer máquina pintável para trocar seu tema. Cada lata tem usos limitados.
