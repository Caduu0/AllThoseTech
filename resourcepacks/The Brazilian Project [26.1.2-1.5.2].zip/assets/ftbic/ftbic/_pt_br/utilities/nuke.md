---
navigation:
  title: Bomba Nuclear e Flecha Nuclear
  icon: ftbic:nuke
  parent: utilities/index.md
  position: 3
item_ids:
  - ftbic:nuke
  - ftbic:active_nuke
  - ftbic:nuke_arrow
---

# <Color id="dark_red">Bomba Nuclear</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="nuke" scale="2" />

  <Color id="red">**Aviso: totalmente destrutiva.**</Color> O raio padrão é de **36 blocos**. Qualquer estrutura dentro dessa esfera é vaporizada e todos os itens soltos desaparecem.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="nuke" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Row>
  <ItemImage id="active_nuke" />
  ### <Color id="aqua">Bomba Nuclear Ativa</Color>
</Row>

Colocada e armada com redstone. Conta regressivamente como TNT acesa, depois detona.

<Row>
  <ItemImage id="nuke_arrow" />
  ### <Color id="aqua">Flecha Nuclear</Color>
</Row>

Uma flecha convencional enrolada numa bomba nuclear. Disparada de um arco, detona no impacto. **Não dispare na sua base.**

<RecipeFor id="nuke_arrow" />
