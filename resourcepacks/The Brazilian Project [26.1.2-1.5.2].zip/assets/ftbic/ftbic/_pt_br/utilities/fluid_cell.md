---
navigation:
  title: Célula de Fluido
  icon: ftbic:fluid_cell
  parent: utilities/index.md
  position: 4
item_ids:
  - ftbic:fluid_cell
---

# <Color id="gold">Célula de Fluido</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="fluid_cell" scale="2" />

  Um recipiente de fluido portátil de 1 balde. Aceita qualquer fluido, empilha até 16 quando as células têm conteúdo idêntico e se integra a toda máquina com espaço de fluido, incluindo o <ItemLink id="geothermal_generator" />.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="fluid_cell" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

* Capacidade: 1.000 mB (um balde).
* Células vazias empilham entre si. Células cheias também empilham quando contêm o mesmo fluido e quantidade.
* Clique com o botão direito num bloco fonte de fluido para encher; clique com o botão direito no ar para esvaziar.
* Insira no espaço de fluido de uma máquina para transferir seu conteúdo para dentro (ou para fora, dependendo da máquina).
* Mais seguras que baldes, já que células soltas não esgotam fontes.
