---
navigation:
  parent: appflux/appflux-index.md
  title: Células de Fluxo
  icon: appflux:fe_1k_cell
categories:
- flux cells
item_ids:
- appflux:fe_cell_housing
- appflux:core_1k
- appflux:core_4k
- appflux:core_16k
- appflux:core_64k
- appflux:core_256k
- appflux:core_1m
- appflux:core_4m
- appflux:core_16m
- appflux:core_64m
- appflux:core_256m
- appflux:fe_1k_cell
- appflux:fe_4k_cell
- appflux:fe_16k_cell
- appflux:fe_64k_cell
- appflux:fe_256k_cell
- appflux:fe_1m_cell
- appflux:fe_4m_cell
- appflux:fe_16m_cell
- appflux:fe_64m_cell
- appflux:fe_256m_cell
---

# Células de Fluxo

<Column>
  <Row>
    <ItemImage id="appflux:fe_1k_cell" scale="4" />
    <ItemImage id="appflux:fe_4k_cell" scale="4" />
    <ItemImage id="appflux:fe_16k_cell" scale="4" />
    <ItemImage id="appflux:fe_64k_cell" scale="4" />
    <ItemImage id="appflux:fe_256k_cell" scale="4" />
  </Row>
  <Row>
    <ItemImage id="appflux:fe_1m_cell" scale="4" />
    <ItemImage id="appflux:fe_4m_cell" scale="4" />
    <ItemImage id="appflux:fe_16m_cell" scale="4" />
    <ItemImage id="appflux:fe_64m_cell" scale="4" />
    <ItemImage id="appflux:fe_256m_cell" scale="4" />
  </Row>
</Column>

A Célula de Armazenamento FE ME é o método principal de armazenamento de energia com o Applied Flux. Suas capacidades são baseadas em bytes, assim como as
[células de armazenamento de itens/fluidos](ae2:items-blocks-machines/storage_cells.md).

# Capacidades das Células

Cada byte pode guardar 1.048.576 FE por padrão, o que pode ser alterado na configuração do Appflux.

| Célula                                 | Capacidade de FE da Célula (Padrão) |
|----------------------------------------|------------------------------:|
| <ItemLink id="appflux:fe_1k_cell" />   |                 1,073,741,824 |
| <ItemLink id="appflux:fe_4k_cell" />   |                 4,294,967,296 |
| <ItemLink id="appflux:fe_16k_cell" />  |                17,179,869,184 |
| <ItemLink id="appflux:fe_64k_cell" />  |                68,719,476,736 |
| <ItemLink id="appflux:fe_256k_cell" /> |               274,877,906,944 |
| <ItemLink id="appflux:fe_1m_cell" />   |             1,099,511,627,776 |
| <ItemLink id="appflux:fe_4m_cell" />   |             4,398,046,511,104 |
| <ItemLink id="appflux:fe_16m_cell" />  |            17,592,186,044,416 |
| <ItemLink id="appflux:fe_64m_cell" />  |            70,368,744,177,664 |
| <ItemLink id="appflux:fe_256m_cell" /> |           281,474,976,710,656 |
