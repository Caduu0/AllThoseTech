---
navigation:
  parent: items-blocks-machines/items-blocks-machines-index.md
  title: Ponto de Acesso sem Fio
  icon: wireless_access_point
  position: 210
categories:
- devices
item_ids:
- ae2:wireless_booster
- ae2:wireless_access_point
---

# O Ponto de Acesso sem Fio

<BlockImage id="wireless_access_point" p:state="has_channel" scale="8" />

Permite acesso sem fio via um <ItemLink id="wireless_terminal" />.
O alcance e o consumo de energia são determinados pelo número de <ItemLink id="wireless_booster" />s instalados.

Uma rede pode ter qualquer número de pontos de acesso sem fio com qualquer quantidade
de <ItemLink id="wireless_booster" />s em cada um, permitindo otimizar o consumo de energia
e o alcance alterando sua configuração.

Requer um [canal](../ae2-mechanics/channels.md).

Também usado para vincular [terminais sem fio](wireless_terminals.md)

# Amplificador de Alcance sem Fio

<ItemImage id="wireless_booster" scale="2" />

Usado para aumentar o alcance do ponto de acesso sem fio.

## Receitas

<RecipeFor id="wireless_access_point" />

<RecipeFor id="wireless_booster" />
