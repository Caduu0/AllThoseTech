---
navigation:
  title: Sincronizador
  icon: deepnullreforged:synchronizer
  parent: items.md
  position: 32
item_ids:
  - deepnullreforged:synchronizer
---

# Sincronizador

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="deepnullreforged:synchronizer" />
</Column>

O Sincronizador armazena um instantâneo da configuração de um Null para que ela possa ser restaurada em outro Null compatível pela Bancada de Trabalho Null.

## O que Ele Armazena

- Configurações de Filtro
- Configurações de melhorias
- Alternâncias de transferência e comportamento
- Outros dados de configuração do Null

Ele **não** copia itens, fluidos, produtos químicos nem energia armazenados.

## Uso

- Insira um Null no slot de entrada à esquerda e um Sincronizador no segundo slot à esquerda da aba Sincronização da Bancada de Trabalho Null
- Pressione **Back Up** para armazenar a configuração do Null no Sincronizador
- Insira um Null compatível novo mais o Sincronizador armazenado e pressione **Restore** para aplicar as configurações salvas
- Ambas as ações levam 3 segundos e devolvem o Null mais o Sincronizador nos dois slots grandes de saída à direita

## Limpeza

- Shift + clique direito no ar com um Sincronizador configurado para limpá-lo
- Coloque um Sincronizador configurado sozinho em qualquer grade de fabricação para limpá-lo

## Fabricação

<RecipeFor id="deepnullreforged:synchronizer" fallbackText="Veja o JEI para a receita atual." />
