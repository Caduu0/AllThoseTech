---
navigation:
  title: Introdução
  icon: auroral:frozen_petals
  parent: index.md
  position: 10
---

# <Color id="gold">Introdução ao Auroral</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="frozen_petals" scale="2" />

  O Auroral transforma biomas frios de terras áridas em centros de progressão de fim de jogo. Domine a Aurora Boreal para fabricar itens mágicos, ferramentas aprimoradas e armaduras poderosas.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">A Aurora</Color>
</Column>

Um evento celestial que ocorre aleatoriamente durante as noites em biomas frios. Quando a aurora está ativa, o céu se enche de faixas cintilantes de luz verde e rosa. É quando a magia acontece.

Enquanto uma aurora está ativa:

* **Aura Líquida** pode ser coletada em <ItemLink id="glacial_basin" />s
* **Equipamentos de Aço Cintilante** se reparam automaticamente
* **Náutilos Aurorais** podem aparecer nos céus
* **Flores da Aurora** surgem em blocos de neve

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Biomas Frios</Color>
</Column>

Os recursos do Auroral são projetados para biomas frios:

* Planícies Nevada
* Picos de Gelo
* Oceano Congelado
* Picos Congelados
* Bosque
* Taiga Nevada

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Caminho de Progressão</Color>
</Column>

1. Espere por uma aurora num bioma frio.
2. Colha <ItemLink id="frozen_petals" /> de Flores da Aurora que surgem naturalmente.
3. Fabrique uma <ItemLink id="glacial_basin" /> e um <ItemLink id="cold_brewing_stand" />.
4. Colete Aura Líquida durante auroras para infundir ferro em <ItemLink id="shimmersteel_ingot" />.
5. Fabrique ferramentas, armas e armaduras aprimoradas.
