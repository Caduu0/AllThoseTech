---
item_ids:
  - auroral:shimmering_ice
navigation:
  title: Gelo Cintilante
  icon: auroral:shimmering_ice
  parent: index.md
  position: 32
---

# <Color id="gold">Gelo Cintilante</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="shimmering_ice" scale="2" />

  Gelo infundido com aurora que brilha suavemente, nunca derrete e hidrata o solo ao redor. A fundação da fazenda de bioma frio.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Obtendo</Color>
</Column>

* Infundindo gelo comum numa <ItemLink id="glacial_basin" /> com Aura Líquida
* Encontrado naturalmente em biomas congelados tocados pela aurora (raro)

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Propriedades</Color>
</Column>

<Row>
  <ItemImage id="shimmering_ice" />
  ### <Color id="aqua">Nunca Derrete</Color>
</Row>

Completamente resistente ao calor e à luz. Perfeito para construções decorativas e caminhos funcionais que precisam durar.

<Row>
  <ItemImage id="shimmering_ice" />
  ### <Color id="aqua">Emissão de Luz</Color>
</Row>

Emite um brilho suave no nível de luz 8 — suficiente para impedir o surgimento de criaturas mantendo o clima.

<Row>
  <ItemImage id="shimmering_ice" />
  ### <Color id="aqua">Hidratação</Color>
</Row>

Hidrata terra arada vanilla e <ItemLink id="shimmer_soil" /> num **raio de 4 blocos**, assim como a água. Combinado com o brilho suave, isso o torna excelente para fazendas subterrâneas sem canais de água.

<Row>
  <ItemImage id="glow_leek" />
  ### <Color id="aqua">Substrato do Alho-Poró Brilhante</Color>
</Row>

<ItemLink id="glow_leek_seeds" /> só podem ser plantadas em Gelo Cintilante — suas propriedades mágicas são essenciais para cultivar a plantação bioluminescente.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Sinergia com Solo Cintilante</Color>
</Column>

Combine Gelo Cintilante com <ItemLink id="shimmer_soil" /> (criado com uma Enxada de Aço Cintilante) para a fazenda definitiva de bioma congelado:

* Gelo Cintilante fornece hidratação **e** luz
* Solo Cintilante acelera plantações — **3x à noite, 5x durante uma aurora**
* Sem necessidade de água — funciona em qualquer lugar

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Usos Resumidos</Color>
</Column>

* Hidratar fazendas de Solo Cintilante sem água
* Cultivar Alho-Poró Brilhante (substrato exclusivo)
* Caminhos de gelo permanentes que nunca derretem
* Construções decorativas com iluminação suave
* Fazendas subterrâneas com iluminação embutida
