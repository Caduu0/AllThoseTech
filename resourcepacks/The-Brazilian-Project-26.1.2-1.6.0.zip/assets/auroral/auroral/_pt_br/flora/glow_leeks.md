---
item_ids:
  - auroral:glow_leek
  - auroral:glow_leek_seeds
  - auroral:candied_glow_leek
navigation:
  title: Alho-Poró Brilhante
  icon: auroral:glow_leek
  parent: index.md
  position: 31
---

# <Color id="gold">Alho-Poró Brilhante</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="glow_leek" scale="2" />

  Vegetais luminescentes que prosperam no frio. Concedem Visão Noturna e Brilho quando comidos.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Sementes</Color>
</Column>

<Row>
  <ItemImage id="glow_leek_seeds" />
  ### <Color id="aqua">Sementes de Alho-Poró Brilhante</Color>
</Row>

Fabricadas combinando <ItemLink id="frozen_petals" /> com **Sementes de Trigo**.

<RecipeFor id="glow_leek_seeds" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Cultivando</Color>
</Column>

Alho-Poró Brilhante cresce apenas em blocos de <ItemLink id="shimmering_ice" />. Não precisam de luz e continuam crescendo durante a noite.

Quando totalmente crescida, quebrar uma planta derruba:

* **Alho-Poró Brilhante** (o vegetal)
* **Sementes de Alho-Poró Brilhante** (para replantar)

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Comendo</Color>
</Column>

Comer um Alho-Poró Brilhante concede:

* **Visão Noturna** — veja claramente no escuro
* **Brilho** — você fica visível para os outros

<Row>
  <ItemImage id="candied_glow_leek" />
  ### <Color id="aqua">Alho-Poró Brilhante Confeitado</Color>
</Row>

Adoçado, sem o efeito brilhante posterior. Apenas Visão Noturna.

<RecipeFor id="candied_glow_leek" />
