---
navigation:
  title: Auroral
  icon: auroral:frozen_petals
  position: 0
---

# <Color id="gold">Auroral</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="frozen_petals" scale="2" />

  Uma expansão de inverno centrada em energia celestial, metalurgia mística e sobrevivência especializada. Domine o poder da Aurora para fabricar equipamentos de Aço Cintilante, armaduras de Trama Cintilante e flores raras que só desabrocham sob as luzes.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

> *"O céu dá, o gelo lembra."*

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Comece Aqui</Color>
</Column>

* <ItemImage id="frozen_petals" scale="0.75"/> [Introdução](getting_started/introduction.md) — o que o Auroral adiciona e como o ciclo se encaixa
* <ItemImage id="glacial_basin" scale="0.75"/> [Primeiros Passos](getting_started/first_steps.md) — sua primeira aurora, sua primeira bacia, seu primeiro lingote

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">A Aurora</Color>
</Column>

* <ItemImage id="aurora_shard" scale="0.75"/> [Eventos da Aurora](aurora/aurora_events.md) — quando as luzes aparecem, o que elas recompensam
* <ItemImage id="auroral_nautilus_spawn_egg" scale="0.75"/> [Criaturas da Aurora](aurora/creatures.md) — Náutilos e Snowlettes atraídos pelas luzes

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Conteúdo</Color>
</Column>

<ItemImage id="minecraft:air" scale="0.5"/>
<Row>
<Column>

### <Color id="aqua">Flora</Color>

* <ItemImage id="frozen_petals" scale="0.75"/> [Flores da Aurora](flora/aurora_blooms.md)
* <ItemImage id="glow_leek" scale="0.75"/> [Alho-Poró Brilhante](flora/glow_leeks.md)
* <ItemImage id="shimmering_ice" scale="0.75"/> [Gelo Cintilante](flora/shimmering_ice.md)
* <ItemImage id="aurora_ender_shard" scale="0.75"/> [Flores de Ender](flora/ender_bloom.md)

### <Color id="aqua">Aço Cintilante</Color>

* <ItemImage id="shimmersteel_ingot" scale="0.75"/> [Lingotes de Aço Cintilante](shimmersteel/ingots.md)
* <ItemImage id="glacial_basin" scale="0.75"/> [Bacia Glacial](shimmersteel/glacial_basin.md)
* <ItemImage id="cold_brewing_stand" scale="0.75"/> [Suporte de Poções Frio](shimmersteel/cold_brewing_stand.md)
* <ItemImage id="shimmersteel_pickaxe" scale="0.75"/> [Ferramentas de Aço Cintilante](shimmersteel/tools.md)
* <ItemImage id="shimmersteel_bow" scale="0.75"/> [Arco de Aço Cintilante](shimmersteel/bow.md)
* <ItemImage id="shimmersteel_ingot" scale="0.75"/> [Ornamentos de Armadura](shimmersteel/armor_trims.md)
* <ItemImage id="shimmer_spear" scale="0.75"/> [Lança Cintilante](shimmersteel/spear.md)

### <Color id="aqua">Trama Cintilante</Color>

* <ItemImage id="shimmerweave_fabric" scale="0.75"/> [Tecido de Trama Cintilante](shimmerweave/fabric.md)
* <ItemImage id="shimmerweave_goggles" scale="0.75"/> [Óculos](shimmerweave/goggles.md)
* <ItemImage id="shimmerweave_tunic" scale="0.75"/> [Túnica](shimmerweave/tunic.md)
* <ItemImage id="shimmerweave_leggings" scale="0.75"/> [Calças](shimmerweave/leggings.md)
* <ItemImage id="shimmerweave_skates" scale="0.75"/> [Patins](shimmerweave/skates.md)

</Column>
<Column>

### <Color id="aqua">Decorações</Color>

* <ItemImage id="snow_angel" scale="0.75"/> [Anjos de Neve](decorations/snow_angel.md)
* <ItemImage id="hearthwood_log" scale="0.75"/> [Tronco de Madeira do Lar](decorations/hearthwood_log.md)
* <ItemImage id="aurora_lantern" scale="0.75"/> [Lampião da Aurora](decorations/aurora_lantern.md)

### <Color id="aqua">Comidas e Bebidas</Color>

* <ItemImage id="hot_cocoa" scale="0.75"/> [Chocolate Quente](food/hot_cocoa.md)
* <ItemImage id="frosted_cookies" scale="0.75"/> [Biscoitos Glaciados](food/frosted_cookies.md)
* <ItemImage id="roasted_snowball" scale="0.75"/> [Bola de Neve Assada](food/roasted_snowball.md)
* <ItemImage id="sugared_roasted_snowball" scale="0.75"/> [Bola de Neve Assada Açucarada](food/sugared_roasted_snowball.md)
* <ItemImage id="snore" scale="0.75"/> [S'nore](food/snore.md)

</Column>
</Row>
