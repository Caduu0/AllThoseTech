---
item_ids:
  - auroral:roasted_snowball
navigation:
  title: Bola de Neve Assada
  icon: auroral:roasted_snowball
  parent: food/index.md
  position: 3
---

# <Color id="gold">Bola de Neve Assada</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="roasted_snowball" scale="2" />

  Uma bola de neve tostada até um dourado suave, com fios de vapor ainda subindo. Parece o menor marshmallow do mundo. O gosto é mais ou menos tão substancial. Os Náutilos não vão perdoar.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="roasted_snowball_from_smelting" />

Fundir uma Bola de Neve numa fornalha também funciona.


<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Propriedades</Color>
</Column>

* **Nutrição Mínima** — restaura apenas meia coxinha de fome
* **Sempre Comestível** — pode ser beliscada mesmo de barriga cheia
* **Ofensiva** — comer uma te marca como transgressor aos olhos da Aurora

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">O Aviso</Color>
</Column>

<Row>
  <ItemImage id="auroral_nautilus_spawn_egg" />
  ### <Color id="aqua">Os Náutilos Ficam Atentos</Color>
</Row>

Comer uma Bola de Neve Assada ofende profundamente os Náutilos Aurorais. Uma vez cometido o ato, Náutilos selvagens **não surgirão mais perto de você** durante auroras. Os céus ficam silenciosos. Os sinos se calam.

Você verá a mensagem *"Os majestosos Náutilos não mais voarão em seus céus"* — e eles falam sério.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Redenção</Color>
</Column>

<Row>
  <ItemImage id="sugared_roasted_snowball" />
  ### <Color id="aqua">Um Pedido de Desculpas Doce</Color>
</Row>

Fabrique uma <ItemLink id="sugared_roasted_snowball" /> e coma-a. Os Náutilos perdoam — um gesto doce e eles agraciam seus céus novamente.

Se você só quer o gosto sem as consequências, coma-a assada num <ItemLink id="snore" />. O biscoito resolve as coisas.
