---
item_ids:
  - auroral:sugared_roasted_snowball
navigation:
  title: Bola de Neve Assada Açucarada
  icon: auroral:sugared_roasted_snowball
  parent: food/index.md
  position: 4
---

# <Color id="gold">Bola de Neve Assada Açucarada</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="sugared_roasted_snowball" scale="2" />

  Uma Bola de Neve Assada enrolada em açúcar até brilhar. O brilho não é magia — é um pedido de desculpas em forma comestível.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="sugared_roasted_snowball" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Propriedades</Color>
</Column>

* **Nutrição Mínima** — o mesmo lanche pequeno da Bola de Neve Assada base
* **Sempre Comestível** — pode ser comida de barriga cheia
* **Sabor de Desculpas** — comer uma faz as pazes com os Náutilos Aurorais

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">O Pedido de Desculpas</Color>
</Column>

<Row>
  <ItemImage id="auroral_nautilus_spawn_egg" />
  ### <Color id="aqua">Os Náutilos Perdoam</Color>
</Row>

Se você comeu uma <ItemLink id="roasted_snowball" />, os Náutilos voaram para longe, enojados. Comer uma Bola de Neve Assada Açucarada diz a eles que você sente muito, e eles voltam na próxima aurora.

Você verá *"Os majestosos Náutilos voam novamente!"* confirmando que sua boa reputação foi restaurada.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Dicas</Color>
</Column>

* Fabrique uma antes de comer a primeira Bola de Neve Assada — você pode se arrepender.
* O brilho a distingue de relance da sua irmã simples.
* Sem efeito se os Náutilos já estiverem a seu favor, mas ainda é docinha.
