---
item_ids:
  - auroral:snore
navigation:
  title: S'nore
  icon: auroral:snore
  parent: food/index.md
  position: 5
---

# <Color id="gold">S'nore</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="snore" scale="2" />

  Dois biscoitos e uma Bola de Neve Assada Açucarada, prensados num sanduíche doce. Surpreendentemente substancioso, e os Náutilos não guardam rancor.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="snore" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Propriedades</Color>
</Column>

* **Refeição Farta** — restaura tanta fome e saturação quanto Bife Assado
* **Poder do Condutor** — 30 segundos: respire debaixo d'água, minere mais rápido submerso, veja claramente através da água
* **Lanche Repousante** — zera o temporizador de insônia dos fantasmas, como se você tivesse dormido
* **Empilha até 16**

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Dicas</Color>
</Column>

* Perfeito antes de uma expedição subaquática. Um S'nore te dá 30 segundos de Poder do Condutor sem toda a cerimônia do Coração do Mar.
* Mantenha um à mão em longas jornadas na superfície para afastar fantasmas sem precisar de cama.
* Diferente de uma <ItemLink id="roasted_snowball" /> crua, comer um S'nore **não** irrita os Náutilos. A cobertura de açúcar resolve as coisas.
