---
item_ids:
  - auroral:glacial_basin
navigation:
  title: Bacia Glacial
  icon: auroral:glacial_basin
  parent: index.md
  position: 41
---

# <Color id="gold">Bacia Glacial</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="glacial_basin" scale="2" />

  Sua estação de trabalho principal. Coleta Aura Líquida durante auroras e a usa para transformar matérias-primas em suas contrapartes mágicas.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="glacial_basin" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Como Funciona</Color>
</Column>

1. **Coloque** a bacia sob o céu aberto.
2. **Espere** uma aurora começar.
3. **Observe** a bacia se encher de Aura Líquida brilhante (até 3 níveis).
4. **Clique com o botão direito** com o item de entrada para transformá-lo.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Transformações</Color>
</Column>

| Entrada | Saída | Custo de Aura |
|-------|--------|-----------|
| <ItemLink id="unrefined_shimmersteel" /> | <ItemLink id="shimmersteel_ingot" /> | 3 (cheio) |
| <ItemLink id="woven_leather" /> | <ItemLink id="shimmerweave_fabric" /> | 1 |
| <ItemLink id="frozen_petals" /> | <ItemLink id="aurora_shard" /> | 1 |
| Gelo | <ItemLink id="shimmering_ice" /> | 1 |

Uma infusão de Lingote de Aço Cintilante exige que a bacia esteja **completamente cheia** e consome os 3 níveis de Aura Líquida de uma vez.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Dicas</Color>
</Column>

* Mantenha várias bacias colocadas para coletar mais aura por evento.
* A bacia precisa de visão livre do céu.
* Auroras duram a noite inteira, então há tempo de sobra para encher.
