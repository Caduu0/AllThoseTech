---
item_ids:
  - auroral:cold_brewing_stand
navigation:
  title: Suporte de Poções Frio
  icon: auroral:cold_brewing_stand
  parent: index.md
  position: 42
---

# <Color id="gold">Suporte de Poções Frio</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="cold_brewing_stand" scale="2" />

  Uma alternativa sem Nether ao Suporte de Poções vanilla. Prepara tudo que o suporte padrão prepara, mas queima bolas de neve em vez de Pó de Blaze.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="cold_brewing_stand" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Como Funciona</Color>
</Column>

O Suporte de Poções Frio se comporta exatamente como o suporte de poções vanilla, com uma diferença chave: **bolas de neve** são o combustível.

Ideal para:

* Jogadas de skyblock ou pacíficas
* Jogadores que ainda não chegaram ao Nether
* Bases de bioma frio onde bolas de neve são abundantes

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Pétalas Congeladas como Vara do Nether</Color>
</Column>

<Row>
  <ItemImage id="frozen_petals" />
  ### <Color id="aqua">Preparando a Poção Base</Color>
</Row>

<ItemLink id="frozen_petals" /> preparam uma **Poção Estranha** a partir de um Frasco de Água, exatamente como a Vara do Nether. A árvore completa de poções se abre sem nunca pisar no Nether.

Passos:

1. Encha o suporte com bolas de neve (até 20).
2. Coloque Frascos de Água nos espaços de baixo.
3. Adicione Pétalas Congeladas no espaço de ingrediente.
4. Espere o preparo terminar — você terá Poções Estranhas.

A partir daí, prepare o resto da árvore de poções com ingredientes padrão.
