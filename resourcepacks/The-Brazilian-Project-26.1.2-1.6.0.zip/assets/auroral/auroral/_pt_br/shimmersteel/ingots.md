---
item_ids:
  - auroral:shimmersteel_ingot
  - auroral:unrefined_shimmersteel
navigation:
  title: Lingotes de Aço Cintilante
  icon: auroral:shimmersteel_ingot
  parent: index.md
  position: 40
---

# <Color id="gold">Lingote de Aço Cintilante</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="shimmersteel_ingot" scale="2" />

  O metal mágico no coração do Auroral. Infundido pela aurora, levemente melhor que ferro, e a porta de entrada para cada ferramenta, arma e acessório aprimorado do mod.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Passo 1 — Aço Cintilante não Refinado</Color>
</Column>

<Row>
  <ItemImage id="unrefined_shimmersteel" />
  ### <Color id="aqua">Ferro + Fragmentos da Aurora</Color>
</Row>

Fabrique Aço Cintilante não Refinado a partir de lingotes de ferro e <ItemLink id="aurora_shard" />s.

<RecipeFor id="unrefined_shimmersteel" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Passo 2 — Infusão na Bacia Glacial</Color>
</Column>

<Row>
  <ItemImage id="glacial_basin" />
  ### <Color id="aqua">Infusão</Color>
</Row>

Infunda o Aço Cintilante não Refinado numa <ItemLink id="glacial_basin" /> cheia de Aura Líquida.

1. Coloque uma Bacia Glacial sob o céu aberto num bioma frio.
2. Espere uma aurora encher a bacia completamente (3/3 de aura).
3. Clique com o botão direito na bacia com o Aço Cintilante não Refinado.
4. A bacia consome **toda** a sua Aura Líquida para produzir um Lingote de Aço Cintilante.

**Importante:** a bacia precisa estar completamente cheia para realizar esta infusão.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Propriedades</Color>
</Column>

* **Alta Encantabilidade** — aceita encantamentos facilmente
* **Afinidade com a Aurora** — ferramentas e armaduras de Aço Cintilante se reparam durante auroras
* **Atributos** — levemente melhor que ferro, abaixo do diamante

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Usos</Color>
</Column>

Lingotes de Aço Cintilante aprimoram equipamentos de ferro pela Mesa de Ferraria. Você precisará de um **Molde de Ferraria de Aprimoramento de Aço Cintilante** para realizar o aprimoramento.

* <ItemImage id="shimmersteel_pickaxe" scale="0.75"/> [Ferramentas de Aço Cintilante](tools.md) — Picareta, Machado, Pá, Enxada, Espada
* <ItemImage id="shimmersteel_bow" scale="0.75"/> [Arco de Aço Cintilante](bow.md) — dispara Disparos Estelares a partir de bolas de neve
* <ItemImage id="shimmer_spear" scale="0.75"/> [Lança Cintilante](spear.md) — lança perfurante de longo alcance
