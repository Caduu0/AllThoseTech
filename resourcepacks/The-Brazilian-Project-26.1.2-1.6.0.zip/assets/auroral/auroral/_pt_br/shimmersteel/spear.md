---
item_ids:
  - auroral:shimmer_spear
navigation:
  title: Lança Cintilante
  icon: auroral:shimmer_spear
  parent: index.md
  position: 45
---

# <Color id="gold">Lança Cintilante</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="shimmer_spear" scale="2" />

  Uma lança perfurante de longo alcance que recompensa golpes comprometidos. Cada acerto aplica Geladura. Durante uma aurora, cada acerto pega mais pesado.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="shimmer_spear_smithing" />

Criada aprimorando uma **Lança de Ferro** numa Mesa de Ferraria com um **Molde de Aprimoramento de Aço Cintilante** e um <ItemLink id="shimmersteel_ingot" />.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Combate com a Lança</Color>
</Column>

<Row>
  <ItemImage id="shimmer_spear" />
  ### <Color id="aqua">Alcance &amp; Carga</Color>
</Row>

* Alcance estendido para golpear de mais longe.
* O dano perfurante interage com escudos de forma diferente de uma espada.
* Clique com o botão direito para carregar uma estocada; solte para um golpe comprometido.
* Carga mínima de ataque de 100% — ataques de cooldown cheio pegam mais pesado.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Geladura ao Atingir</Color>
</Column>

Cada golpe certeiro aplica Geladura ao alvo. A Geladura desacelera o movimento, reduz cura e armadura, e faz escudos se desgastarem mais rápido. Golpes seguintes renovam o efeito.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Aprimoramento da Aurora</Color>
</Column>

* Durante auroras, cada estocada causa dano adicional.
* A Geladura potencializada pela aurora dura o dobro com força maior.
* Partículas de aurora saem dos impactos.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Dicas</Color>
</Column>

* Use o alcance para espetar através de multidões e cercas sem se expor.
* Cronometre uma estocada de carga cheia quando os inimigos se aproximarem — golpes parciais pegam mais leve.
* Combina bem com <ItemLink id="shimmerweave_skates" /> para kitando no gelo.
* Uma aurora no céu é uma ótima janela para encarar lutas mais difíceis.
