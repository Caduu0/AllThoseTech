---
navigation:
  title: Tronco de Madeira do Lar
  icon: auroral:hearthwood_log
  parent: index.md
  position: 62
item_ids:
  - auroral:hearthwood_log
---

# <Color id="gold">Tronco de Madeira do Lar</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="hearthwood_log" scale="2" />

  Um tronco mágico que queima com uma chama encantada. Uma Madeira do Lar acesa contém a Geladura, repele Fantasmas e inclina a noite para uma aurora.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Obtendo</Color>
</Column>

Troncos de Madeira do Lar crescem naturalmente em biomas frios e aparecem em:

* Vilas de Taiga Nevada
* Estruturas congeladas
* Porões de iglus (ocasionalmente)

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Acendendo</Color>
</Column>

Clique com o botão direito no tronco com uma **Pederneira** para acendê-lo. Uma vez aceso, ele queima com um brilho mágico e quente e começa a emitir seus efeitos passivos. Um tronco apagado pode ser reaceso da mesma forma.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Efeitos</Color>
</Column>

<Row>
  <ItemImage id="hearthwood_log" />
  ### <Color id="aqua">Queima Prolongada</Color>
</Row>

Um Tronco de Madeira do Lar aceso queima por **7 dias dentro do jogo** de tempo com chunk carregado (168.000 tiques, cerca de 2 horas e 20 minutos de jogo contínuo). O temporizador só diminui enquanto o chunk está ativo, então troncos em chunks raramente visitados duram muito mais em tempo real. O tempo de queima é configurável na configuração do servidor.

<Row>
  <ItemImage id="hearthwood_log" />
  ### <Color id="aqua">Imunidade à Geladura</Color>
</Row>

Jogadores num raio de **16 blocos** de um tronco aceso ficam imunes à Geladura. Faça um anel deles e sua base ficará segura durante o pior do inverno.

<Row>
  <ItemImage id="hearthwood_log" />
  ### <Color id="aqua">Proteção contra Fantasmas</Color>
</Row>

Qualquer Fantasma que entrar num raio de 16 blocos de um tronco aceso pega fogo ao contato. Fantasmas também se recusam a atacar jogadores atualmente aquecidos pela Imunidade à Geladura, então um anel de Madeiras do Lar acesas mantém os céus noturnos limpos.

<Row>
  <ItemImage id="hearthwood_log" />
  ### <Color id="aqua">Catalisador da Aurora</Color>
</Row>

Um tronco aceso num raio de **32 blocos** de um jogador num bioma frio adiciona **+15% de chance de aurora** ao anoitecer. Até três troncos acumulam para **+45%**, elevando a chance de aurora noturna a cerca de 78% nas configurações padrão. Troncos além do terceiro não acumulam.

<Row>
  <ItemImage id="hearthwood_log" />
  ### <Color id="aqua">Conforto dos Aldeões</Color>
</Row>

Aldeões perto de um tronco aceso se sentem mais à vontade e podem oferecer trocas melhores.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Dicas</Color>
</Column>

* Coloque troncos ao redor da sua base de bioma frio para proteção permanente contra Geladura.
* O brilho quente também serve como iluminação ambiente.
* Três troncos acesos são o ponto ideal para o bônus de aurora; o quarto não faz nada extra.
