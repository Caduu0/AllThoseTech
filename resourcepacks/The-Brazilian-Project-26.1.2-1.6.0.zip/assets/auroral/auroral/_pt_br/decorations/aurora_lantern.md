---
item_ids:
  - auroral:aurora_lantern
navigation:
  title: Lampião da Aurora
  icon: auroral:aurora_lantern
  parent: index.md
  position: 61
---

# <Color id="gold">Lampião da Aurora</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="aurora_lantern" scale="2" />

  Uma fonte de luz decorativa que captura o brilho etéreo das luzes do norte — e dissipa trevas mágicas quando segurada.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="aurora_lantern" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Propriedades</Color>
</Column>

* **Nível de Luz 15** — brilho máximo
* **Mudança de Cor** — alterna suavemente pelos tons da aurora (verde, azul, rosa)
* **Posicionável** — cabe no chão, em paredes ou pendurado no teto
* **À Prova d'Água** — funciona debaixo d'água sem se apagar

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Imunidade às Trevas</Color>
</Column>

<Row>
  <ItemImage id="aurora_lantern" />
  ### <Color id="aqua">Segurado na Mão</Color>
</Row>

Enquanto segurado na mão principal ou secundária, o Lampião da Aurora concede imunidade ao efeito Trevas. Seu brilho etéreo dissipa trevas mágicas, tornando-o indispensável ao explorar biomas das Profundezas (s)ombrias ou lutar contra o Sentinela.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Usos</Color>
</Column>

* Iluminar construções em biomas frios
* Criar uma atmosfera encantada
* Marcar caminhos por terrenos nevados
* Decorar áreas com tema de Trama Cintilante
