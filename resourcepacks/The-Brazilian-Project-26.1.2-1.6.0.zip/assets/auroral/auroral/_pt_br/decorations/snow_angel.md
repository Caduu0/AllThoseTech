---
item_ids:
  - auroral:snow_angel
navigation:
  title: Anjos de Neve
  icon: auroral:snow_angel
  parent: index.md
  position: 60
---

# <Color id="gold">Anjos de Neve</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="snow_angel" scale="2" />

  Uma marca divertida deixada na neve fresca. Temporária por padrão — preserve-a com uma Pétala Congelada para mantê-la para sempre.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Criando um Anjo de Neve</Color>
</Column>

**Agache e clique com o botão direito** em qualquer superfície de neve com **as duas mãos vazias**. Seu personagem deixa uma marca na neve, criando um padrão decorativo de anjo de neve.

Um anjo de neve é marcado como um bloco *substituível* — você pode colocar um novo bloco diretamente no espaço dele sem quebrá-lo antes, da mesma forma que faria sobre grama alta ou uma camada de neve.

Superfícies válidas:

* Camadas de neve
* Blocos de neve
* Neve em pó

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Desvanecendo</Color>
</Column>

Anjos de neve são temporários por natureza. Como pegadas na neve fresca, eles desaparecem após **5 minutos** se deixados sozinhos.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Preservando</Color>
</Column>

<Row>
  <ItemImage id="frozen_petals" />
  ### <Color id="aqua">Botão Direito com uma Pétala Congelada</Color>
</Row>

Clique com o botão direito num anjo de neve com uma <ItemLink id="frozen_petals" />. A magia da pétala cristaliza o anjo de neve, impedindo que ele desvaneça. Anjos de neve preservados permanecem até serem quebrados.

Pétalas Congeladas vêm da colheita de <ItemLink id="aurora_bloom" />s totalmente crescidas durante uma aurora.
