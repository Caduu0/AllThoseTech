---
item_ids:
  - auroral:shimmerweave_fabric
  - auroral:woven_leather
navigation:
  title: Tecido de Trama Cintilante
  icon: auroral:shimmerweave_fabric
  parent: index.md
  position: 50
---

# <Color id="gold">Tecido de Trama Cintilante</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="shimmerweave_fabric" scale="2" />

  Pano infundido com aurora — leve, durável e a fundação de cada peça de armadura de Trama Cintilante.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Infusão na Bacia Glacial</Color>
</Column>

<Row>
  <ItemImage id="glacial_basin" />
  ### <Color id="aqua">Couro ou Lã → Tecido</Color>
</Row>

Infunda Couro ou Lã de qualquer cor numa <ItemLink id="glacial_basin" /> cheia de Aura Líquida.

1. Coloque uma Bacia Glacial sob o céu aberto.
2. Espere uma aurora enchê-la.
3. Clique com o botão direito na bacia com Couro ou Lã.
4. Receba Tecido de Trama Cintilante.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Couro Tecido</Color>
</Column>

<Row>
  <ItemImage id="woven_leather" />
  ### <Color id="aqua">Fabricado a partir de Couro</Color>
</Row>

Algumas receitas pedem Couro Tecido, fabricado a partir de couro comum.

<RecipeFor id="woven_leather" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Propriedades</Color>
</Column>

* **Leve** — armadura feita de Trama Cintilante tem peso mínimo
* **Afinidade com a Aurora** — a armadura se repara durante auroras
* **Condutividade Mágica** — ativa a habilidade especial de cada peça

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Usos</Color>
</Column>

O Tecido de Trama Cintilante aprimora armaduras de ferro na Mesa de Ferraria. Você precisará de um **Molde de Ferraria de Aprimoramento de Aço Cintilante** para realizar o aprimoramento.

* <ItemImage id="shimmerweave_goggles" scale="0.75"/> [Óculos de Trama Cintilante](goggles.md) — revela inimigos ocultos
* <ItemImage id="shimmerweave_tunic" scale="0.75"/> [Túnica de Trama Cintilante](tunic.md) — proteção contra fogo
* <ItemImage id="shimmerweave_leggings" scale="0.75"/> [Calças de Trama Cintilante](leggings.md) — velocidade na neve
* <ItemImage id="shimmerweave_skates" scale="0.75"/> [Patins de Trama Cintilante](skates.md) — mestres do gelo
