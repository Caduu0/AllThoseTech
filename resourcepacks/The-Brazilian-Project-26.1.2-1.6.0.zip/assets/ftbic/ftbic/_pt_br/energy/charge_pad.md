---
navigation:
  title: Plataforma de Carga
  icon: ftbic:charge_pad
  parent: energy/index.md
  position: 5
item_ids:
  - ftbic:charge_pad
---

# <Color id="gold">Plataforma de Carga</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="charge_pad" scale="2" />

  Um bloco plano que recarrega qualquer item energizado que um jogador esteja vestindo ou carregando, simplesmente ficando em cima dele.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="charge_pad" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Uso</Color>
</Column>

* Ligue energia em qualquer face. A plataforma aceita entrada de até **IV**.
* Amortecedor interno: <Energy config="machines.charge_pad_capacity" />.
* Fique em cima para recarregar armaduras vestidas (<ItemLink id="carbon_chestplate" />, <ItemLink id="quantum_chestplate" />, <ItemLink id="mechanical_elytra" />) e quaisquer baterias no inventário.
* Abra a plataforma para carregar até quatro itens recarregáveis inseridos, incluindo peitorais de Carbono e Quantum.
* Ficar em cima da plataforma e carregar itens inseridos consomem de seu amortecedor de energia.

Combine com uma <ItemLink id="ev_battery_box" /> acima de uma estação de jogador para recarga rápida após cada expedição.
