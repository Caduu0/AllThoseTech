---
navigation:
  title: Transformadores
  icon: ftbic:mv_transformer
  parent: energy/index.md
  position: 3
item_ids:
  - ftbic:lv_transformer
  - ftbic:mv_transformer
  - ftbic:hv_transformer
  - ftbic:ev_transformer
---

# <Color id="gold">Transformadores</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="mv_transformer" scale="2" />

  Transformadores reduzem a voltagem de um nível mais alto para um mais baixo. Eles não conseguem elevar a voltagem. Todo transformador tem uma única face de nível mais alto e cinco faces de nível mais baixo.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

Sem um transformador, alimentar HV numa máquina LV a queima instantaneamente. Transformadores dividem um sinal de nível N para o nível abaixo na taxa de transferência correspondente.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Row>
  <ItemImage id="lv_transformer" />
  ### <Color id="aqua">Transformador LV</Color>
</Row>

Reduz MV (<Energy config="energy.mv_transfer_rate" rate="true" />) para LV (<Energy config="energy.lv_transfer_rate" rate="true" />).

<RecipeFor id="lv_transformer" />

<Row>
  <ItemImage id="mv_transformer" />
  ### <Color id="aqua">Transformador MV</Color>
</Row>

Reduz HV (<Energy config="energy.hv_transfer_rate" rate="true" />) para MV (<Energy config="energy.mv_transfer_rate" rate="true" />).

<RecipeFor id="mv_transformer" />

<Row>
  <ItemImage id="hv_transformer" />
  ### <Color id="aqua">Transformador HV</Color>
</Row>

Reduz EV (<Energy config="energy.ev_transfer_rate" rate="true" />) para HV (<Energy config="energy.hv_transfer_rate" rate="true" />).

<RecipeFor id="hv_transformer" />

<Row>
  <ItemImage id="ev_transformer" />
  ### <Color id="aqua">Transformador EV</Color>
</Row>

Reduz IV (<Energy config="energy.iv_transfer_rate" rate="true" />) para EV (<Energy config="energy.ev_transfer_rate" rate="true" />).

<RecipeFor id="ev_transformer" />
