---
navigation:
  title: Retificadores de Energia
  icon: ftbic:mv_rectifier
  parent: energy/index.md
  position: 4
item_ids:
  - ftbic:lv_rectifier
  - ftbic:mv_rectifier
  - ftbic:hv_rectifier
  - ftbic:ev_rectifier
  - ftbic:iv_rectifier
---

# <Color id="gold">Retificadores de Energia</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="hv_rectifier" scale="2" />

  Cabos e geradores do FTBIC já **empurram FE** para qualquer bloco que aceite FE. Você não precisa de um retificador para rodar pedreiras do vanilla, máquinas do mekanism ou qualquer outro mod que consuma FE.

  <ZapMode>

  Você **precisa** de um retificador quando uma fonte produtora de FE precisa alimentar energia **para dentro** de uma máquina ou rede FTBIC. Máquinas FTBIC não aceitam FE diretamente; o retificador é o adaptador de mão única que converte o FE recebido em zaps.

  </ZapMode>

  <FEMode>

  O **modo FE completo** está ativado, então retificadores ficam ocultos e não podem ser fabricados. Toda máquina FTBIC aceita FE diretamente em suas faces. A entrada de FE é limitada à taxa de entrada da máquina e nunca a queima.

  </FEMode>
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<ZapMode>

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Como Funcionam</Color>
</Column>

Um retificador é direcional. Sua **face FE** aceita Forge Energy de um cabo, gerador ou bloco de armazenamento produtor de FE adjacente. As demais faces emitem a energia convertida como zaps para a rede FTBIC.

A taxa de conversão é **1 zap = 8 FE** por padrão (configurável). O retificador de cada nível converte na taxa de transferência de voltagem correspondente:

| Retificador | Taxa de zaps |
|-----------|----------|
| LV | <Energy config="energy.lv_transfer_rate" rate="true" /> |
| MV | <Energy config="energy.mv_transfer_rate" rate="true" /> |
| HV | <Energy config="energy.hv_transfer_rate" rate="true" /> |
| EV | <Energy config="energy.ev_transfer_rate" rate="true" /> |
| IV | <Energy config="energy.iv_transfer_rate" rate="true" /> |

Se você só precisa alimentar máquinas **FE** a partir de geradores FTBIC, pule o retificador por completo. Qualquer face de saída de cabo ou máquina FTBIC empurra FE por conta própria.

<ItemImage id="minecraft:air" scale="0.25"/>
***

</ZapMode>

<Row>
  <ItemImage id="lv_rectifier" />
  ### <Color id="aqua">Retificador de Energia LV</Color>
</Row>

<RecipeFor id="lv_rectifier" fallbackText="Não fabricável enquanto o modo FE completo estiver ativado." />

<Row>
  <ItemImage id="mv_rectifier" />
  ### <Color id="aqua">Retificador de Energia MV</Color>
</Row>

<RecipeFor id="mv_rectifier" fallbackText="Não fabricável enquanto o modo FE completo estiver ativado." />

<Row>
  <ItemImage id="hv_rectifier" />
  ### <Color id="aqua">Retificador de Energia HV</Color>
</Row>

<RecipeFor id="hv_rectifier" fallbackText="Não fabricável enquanto o modo FE completo estiver ativado." />

<Row>
  <ItemImage id="ev_rectifier" />
  ### <Color id="aqua">Retificador de Energia EV</Color>
</Row>

<RecipeFor id="ev_rectifier" fallbackText="Não fabricável enquanto o modo FE completo estiver ativado." />

<Row>
  <ItemImage id="iv_rectifier" />
  ### <Color id="aqua">Retificador de Energia IV</Color>
</Row>

<RecipeFor id="iv_rectifier" fallbackText="Não fabricável enquanto o modo FE completo estiver ativado." />
