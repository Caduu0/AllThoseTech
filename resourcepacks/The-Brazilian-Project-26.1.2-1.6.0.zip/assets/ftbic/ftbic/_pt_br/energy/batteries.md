---
navigation:
  title: Baterias e Caixas de Bateria
  icon: ftbic:hv_battery
  parent: energy/index.md
  position: 2
item_ids:
  - ftbic:single_use_battery
  - ftbic:lv_battery
  - ftbic:mv_battery
  - ftbic:hv_battery
  - ftbic:ev_battery
  - ftbic:creative_battery
  - ftbic:lv_battery_box
  - ftbic:mv_battery_box
  - ftbic:hv_battery_box
  - ftbic:ev_battery_box
  - ftbic:industrial_bank_cell
  - ftbic:industrial_bank_port
  - ftbic:energy_crystal
---

# <Color id="gold">Baterias e Caixas de Bateria</Color>

## <Color id="gold">Banco de Baterias Industrial</Color>

Coloque uma <ItemLink id="industrial_bank_cell" /> e uma <ItemLink id="industrial_bank_port" /> face a face para formar um banco. Cada célula adiciona armazenamento; cada porta aceita e fornece energia por suas faces expostas. Adicione mais portas para mais conexões. Clique com o botão direito em qualquer célula ou porta para ver a carga, a capacidade e a contagem de membros do banco. A tela de uma porta também tem quatro espaços de **carga** que carregam baterias e outros itens de energia a partir do banco. A configuração de lados de uma porta pode restringir as faces de entrada e saída.

Cada célula armazena <Energy config="energy.bank_cell_capacity" />. Cada porta emite automaticamente até <Energy config="energy.bank_port_transfer" rate="true" /> e aceita até essa quantidade numa única transação de entrada. A energia recebida se move para as células conectadas para que a porta continue aceitando energia. A configuração do servidor controla ambos os valores e o número máximo de blocos pesquisados por banco. A energia permanece em cada célula se você dividir o banco, e reconectar células restaura a leitura compartilhada. As carcaças do banco se unem visualmente nas faces que se tocam.

Agache e clique com o botão direito numa porta para alternar sua aparência: **Porta** (o símbolo de conexão padrão), **Medidor** e depois **Básico** (aço simples como uma célula). A escolha pertence àquela porta e sobrevive a um recarregamento do mundo. Mudar a aparência não altera a entrada ou saída de energia. O estilo selecionado aparece brevemente acima da barra rápida.

O Medidor mostra o nível de enchimento do banco inteiro com uma barra brilhante. Configure portas vizinhas como Medidor na mesma face plana para formar um display mais largo ou alto. Um retângulo de portas Medidor se enche de baixo para cima no painel inteiro. Estilos Básico e Porta interrompem o display, assim como lacunas, faces cobertas e cantos. Formas irregulares de Medidor formam painéis retangulares menores.

<RecipeFor id="industrial_bank_cell" />
<RecipeFor id="industrial_bank_port" />

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="hv_battery_box" scale="2" />

  Baterias são energia portátil. Caixas de bateria são amortecedores de rede: coloque baterias dentro e elas carregam, ou retire-as carregadas para alimentar um dispositivo de mão.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Baterias de Mão</Color>
</Column>

<Row>
  <ItemImage id="single_use_battery" />
  ### <Color id="aqua">Bateria de Uso Único</Color>
</Row>

Uma bateria descartável e barata. <Energy config="energy.single_use_battery_capacity" />. Boa para emergências, inútil para infraestrutura.

<RecipeFor id="single_use_battery" />

<Row>
  <ItemImage id="lv_battery" />
  ### <Color id="aqua">Bateria LV</Color>
</Row>

Armazena <Energy config="energy.lv_battery_capacity" />, nível LV. A primeira bateria recarregável.

<RecipeFor id="lv_battery" />

<Row>
  <ItemImage id="mv_battery" />
  ### <Color id="aqua">Bateria MV</Color>
</Row>

<Energy config="energy.mv_battery_capacity" />. Melhoria da bateria LV usando <ItemLink id="energy_crystal" />.

<RecipeFor id="mv_battery" />

<Row>
  <ItemImage id="hv_battery" />
  ### <Color id="aqua">Bateria HV</Color>
</Row>

<Energy config="energy.hv_battery_capacity" />. Alimenta equipamentos de mão de meio a fim de jogo.

<RecipeFor id="hv_battery" />

<Row>
  <ItemImage id="ev_battery" />
  ### <Color id="aqua">Bateria EV</Color>
</Row>

<Energy config="energy.ev_battery_capacity" />. A maior bateria portátil do mod.

<RecipeFor id="ev_battery" />

<Row>
  <ItemImage id="creative_battery" />
  ### <Color id="aqua">Bateria Criativa</Color>
</Row>

Energia infinita. Apenas no criativo.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Caixas de Bateria</Color>
</Column>

Uma caixa de bateria tem um espaço de **descarga** à esquerda e um espaço de **carga** à direita. Coloque uma bateria carregada no espaço de descarga para alimentar a caixa; coloque uma bateria vazia ou outro item de energia no espaço de carga para recarregá-lo. Cada caixa também tem um amortecedor interno correspondente ao seu nível.

Abra **E/S**, escolha **Energia** e configure qualquer face como **Saída** para enviar energia para lá. Você pode configurar várias faces como Saída. Configure uma face como **Entrada** para receber energia, **Ambos** para permitir as duas direções, ou **Desativado** para desconectá-la. **Padrão** mantém o arranjo original: a frente emite e as outras faces recebem. Cada face alterna entre a textura de entrada e saída quando seu papel de saída muda. Os mesmos controles funcionam nas Caixas de Bateria LV, MV, HV e EV.

<Row>
  <ItemImage id="lv_battery_box" />
  ### <Color id="aqua">Caixa de Bateria LV (<Energy config="energy.lv_battery_box_capacity" />)</Color>
</Row>

<RecipeFor id="lv_battery_box" />

<Row>
  <ItemImage id="mv_battery_box" />
  ### <Color id="aqua">Caixa de Bateria MV (<Energy config="energy.mv_battery_box_capacity" />)</Color>
</Row>

<RecipeFor id="mv_battery_box" />

<Row>
  <ItemImage id="hv_battery_box" />
  ### <Color id="aqua">Caixa de Bateria HV (<Energy config="energy.hv_battery_box_capacity" />)</Color>
</Row>

<RecipeFor id="hv_battery_box" />

<Row>
  <ItemImage id="ev_battery_box" />
  ### <Color id="aqua">Caixa de Bateria EV (<Energy config="energy.ev_battery_box_capacity" />)</Color>
</Row>

<RecipeFor id="ev_battery_box" />

<ItemImage id="minecraft:air" scale="0.25"/>

<Row>
  <ItemImage id="energy_crystal" />
  ### <Color id="aqua">Cristal de Energia</Color>
</Row>

Um bloco comprimido de diamantes e redstone. Necessário para fabricar baterias MV+ e dispositivos de alta capacidade.

<RecipeFor id="energy_crystal" />
