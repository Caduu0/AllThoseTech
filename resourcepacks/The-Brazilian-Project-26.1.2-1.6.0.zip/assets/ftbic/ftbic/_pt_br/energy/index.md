---
navigation:
  title: Rede de Energia
  icon: ftbic:lv_cable
  position: 10
---

# <Color id="gold">Rede de Energia</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="lv_cable" scale="2" />

  <ZapMode>

  O FTBIC funciona com sua própria unidade de energia, o **zap**. Todo cabo, bateria e máquina usa zaps internamente. Geradores e cabos do FTBIC podem alimentar máquinas que consomem FE diretamente. Alimentar FE **para dentro** de uma máquina FTBIC requer um <ItemLink id="lv_rectifier" />.

  </ZapMode>

  <FEMode>

  O **modo FE completo** está ativado, então o FTBIC funciona em Forge Energy (FE). Toda GUI, tooltip, página do JEI e leitura do Jade mostra energia em FE. Blocos do FTBIC trocam FE diretamente com outros mods: geradores e cabos empurram FE para máquinas de outros mods, e toda máquina FTBIC aceita FE em suas faces, então nenhum retificador é necessário.

  </FEMode>

  Quando o FTBIC empurra energia para um consumidor FE por um cabo, o fluxo é limitado à taxa de transferência do nível do cabo. Um cabo LV ligado a uma máquina FE que beberia milhares de FE por tique ainda entrega apenas <Energy config="energy.lv_transfer_rate" rate="true" /><ZapMode> em FE</ZapMode>, mantendo o cabo seguro em vez de queimá-lo.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Níveis de Voltagem</Color>
</Column>

Todo cabo e todo bloco é classificado para um dos cinco níveis de voltagem. Alimente um bloco com mais do que seu nível permite e ele **queima**.

| Nível | Abrev. | Taxa de transferência | Uso típico |
|------|--------|---------------|-------------|
| Baixa     | **LV** | <Energy config="energy.lv_transfer_rate" rate="true" /> | Primeiro gerador, primeiras máquinas |
| Média  | **MV** | <Energy config="energy.mv_transfer_rate" rate="true" /> | Cadeias de processamento de minérios |
| Alta    | **HV** | <Energy config="energy.hv_transfer_rate" rate="true" /> | Máquinas avançadas |
| Extrema | **EV** | <Energy config="energy.ev_transfer_rate" rate="true" /> | Nuclear, teletransportadores, quantum |
| Insana  | **IV** | <Energy config="energy.iv_transfer_rate" rate="true" /> | Antimatéria, fim de jogo |

**Regra prática:** combine o nível do cabo com o maior produtor ou consumidor conectado a ele. Use blocos da família <ItemLink id="lv_transformer" /> para reduzir a voltagem para um nível menor.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Queima e Fusíveis</Color>
</Column>

Um cabo que recebe voltagem alta demais vira um <ItemLink id="burnt_cable" />. Uma máquina também derrete: sua entidade de bloco vira uma carcaça queimada até ser reparada com um <ItemLink id="fuse" />.

<FEMode>

Entrada de FE nunca queima nada. Quando outro mod envia FE para uma máquina FTBIC, a máquina recebe até sua própria taxa de entrada e recusa o resto. Sobretensão vinda de cabos FTBIC ainda queima máquinas LV e MV, caixas de bateria e transformadores.

</FEMode>

Cabos queimados podem ser reciclados em <ItemLink id="scrap" />.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Subseções</Color>
</Column>

<SubPages icons={true} />
