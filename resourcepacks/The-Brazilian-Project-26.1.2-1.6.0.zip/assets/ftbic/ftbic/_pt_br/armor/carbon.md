---
navigation:
  title: Armadura de Carbono
  icon: ftbic:carbon_chestplate
  parent: armor/index.md
  position: 1
item_ids:
  - ftbic:carbon_helmet
  - ftbic:carbon_chestplate
  - ftbic:carbon_leggings
  - ftbic:carbon_boots
---

# <Color id="gold">Armadura de Carbono</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="carbon_chestplate" scale="2" />

  O conjunto de armadura energizada de nível inicial. Absorve dano gastando <Energy config="equipment.armor_damage_energy" /> por ponto de dano absorvido, em vez de perder durabilidade. Capacidade: **<Energy config="equipment.carbon_armor_capacity" />** no peitoral.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Row>
  <ItemImage id="carbon_helmet" />
  ### <Color id="aqua">Capacete de Carbono</Color>
</Row>

<RecipeFor id="carbon_helmet" />

<Row>
  <ItemImage id="carbon_chestplate" />
  ### <Color id="aqua">Peitoral de Carbono</Color>
</Row>

Guarda a reserva de energia do conjunto inteiro.

<RecipeFor id="carbon_chestplate" />

<Row>
  <ItemImage id="carbon_leggings" />
  ### <Color id="aqua">Calças de Carbono</Color>
</Row>

<RecipeFor id="carbon_leggings" />

<Row>
  <ItemImage id="carbon_boots" />
  ### <Color id="aqua">Botas de Carbono</Color>
</Row>

<RecipeFor id="carbon_boots" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

Sem um peitoral carregado, as outras peças não oferecem proteção. Uma carga baixa absorve apenas o tanto de dano que a carga restante consegue cobrir.
