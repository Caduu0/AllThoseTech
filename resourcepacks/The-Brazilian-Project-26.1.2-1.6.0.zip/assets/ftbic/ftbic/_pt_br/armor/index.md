---
navigation:
  title: Armadura Energizada
  icon: ftbic:quantum_chestplate
  position: 50
---

# <Color id="gold">Armadura Energizada</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="quantum_chestplate" scale="2" />

  A armadura do FTBIC consome **<EnergyUnit />** para absorver dano e alimentar o voo. Os peitorais guardam a energia do conjunto inteiro. As peças nunca se desgastam, mas não oferecem proteção quando o peitoral correspondente está vazio ou ausente.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Carregando</Color>
</Column>

Vista o peitoral e fique sobre uma <ItemLink id="charge_pad" /> energizada, ou coloque o peitoral em um de seus quatro espaços de carregamento. As outras peças de armadura não armazenam energia.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Subseções</Color>
</Column>

<SubPages icons={true} />
