---
navigation:
  title: Élitro Mecânico
  icon: ftbic:mechanical_elytra
  parent: armor/index.md
  position: 3
item_ids:
  - ftbic:mechanical_elytra
---

# <Color id="gold">Élitro Mecânico</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="mechanical_elytra" scale="2" />

  Um élitro energizado com proteção de peitoral de ferro e uma textura de asa dedicada. Ele recarrega à luz do dia sob céu aberto e plana enquanto tiver carga.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="mechanical_elytra" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

* Capacidade: **<Energy config="equipment.mechanical_elytra_capacity" />**.
* Taxa de recarga passiva: <Energy config="equipment.mechanical_elytra_recharge" rate="true" /> enquanto usado à luz do dia sob céu aberto, e não enquanto plana. A recarga completa leva cerca de 40 minutos partindo de vazio.
* Também pode ser carregado numa <ItemLink id="charge_pad" /> ou caixa de bateria.
* Usa o espaço do peitoral, então não pode ser combinado com um peitoral de armadura energizada. Segure agachar enquanto plana para desacelerar.
