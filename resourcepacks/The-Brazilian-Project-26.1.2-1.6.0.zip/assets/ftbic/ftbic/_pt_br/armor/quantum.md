---
navigation:
  title: Armadura Quantum
  icon: ftbic:quantum_chestplate
  parent: armor/index.md
  position: 2
item_ids:
  - ftbic:quantum_helmet
  - ftbic:quantum_chestplate
  - ftbic:quantum_leggings
  - ftbic:quantum_boots
---

# <Color id="gold">Armadura Quantum</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="quantum_chestplate" scale="2" />

  A armadura energizada de fim de jogo. Mesmo modelo de proteção da de carbono, mas com um reservatório de **<Energy config="equipment.quantum_armor_capacity" />**, voo e absorção total de dano em taxas de carga EV.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Row>
  <ItemImage id="quantum_helmet" />
  ### <Color id="aqua">Capacete Quantum</Color>
</Row>

<RecipeFor id="quantum_helmet" />

<Row>
  <ItemImage id="quantum_chestplate" />
  ### <Color id="aqua">Peitoral Quantum</Color>
</Row>

Guarda a energia do conjunto inteiro. Pressione pular duas vezes para pairar e voar enquanto carregado. Pairar gasta <Energy config="equipment.armor_flight_energy" rate="true" />. O peitoral também suporta planar; segure pular para acelerar ou agachar para desacelerar enquanto plana.

<RecipeFor id="quantum_chestplate" />

<Row>
  <ItemImage id="quantum_leggings" />
  ### <Color id="aqua">Calças Quantum</Color>
</Row>

<RecipeFor id="quantum_leggings" />

<Row>
  <ItemImage id="quantum_boots" />
  ### <Color id="aqua">Botas Quantum</Color>
</Row>

<RecipeFor id="quantum_boots" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Dicas</Color>
</Column>

* O peitoral consome <Energy config="equipment.armor_flight_energy" rate="true" /> enquanto paira ou plana. Acelerar e frear durante o planeio usam energia adicional.
* A absorção de dano usa apenas energia armazenada. As peças nunca perdem durabilidade e não oferecem proteção quando o peitoral está vazio.
* Coloque uma <ItemLink id="charge_pad" /> sobre uma <ItemLink id="ev_battery_box" /> para que pisar nela recarregue o conjunto inteiro instantaneamente.
