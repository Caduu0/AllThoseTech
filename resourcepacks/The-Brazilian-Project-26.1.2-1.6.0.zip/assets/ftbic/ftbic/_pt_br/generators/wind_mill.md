---
navigation:
  title: Moinho de Vento
  icon: ftbic:wind_mill
  parent: generators/index.md
  position: 4
item_ids:
  - ftbic:wind_mill
---

# <Color id="gold">Moinho de Vento</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="wind_mill" scale="2" />

  Um gerador dependente de altura que escala de **<ZapMode>0,3 z/t</ZapMode><FEMode><Energy config="machines.wind_mill_min_output" rate="true" /></FEMode>** perto do nível do mar até **<ZapMode>6,5 z/t</ZapMode><FEMode><Energy config="machines.wind_mill_max_output" rate="true" /></FEMode>** em altitudes próximas ao limite de construção.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="wind_mill" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Regras de Posicionamento</Color>
</Column>

* Mínimo efetivo de **Y=64**. Abaixo disso, não produz nada.
* A produção escala linearmente de Y=64 até **Y=319**.
* Precisa de espaço livre ao redor das pás. Paredes bloqueiam o fluxo de ar.
* **Chuva** multiplica a produção por 1,2×.
* **Tempestades** multiplicam a produção por 1,5×.

<ItemImage id="minecraft:air" scale="0.25"/>
***

Útil como recarga passiva e como motivo para construir alto. Um pilar de 10 a 20 moinhos de vento numa montanha é uma fonte de energia estável de início de MV.
