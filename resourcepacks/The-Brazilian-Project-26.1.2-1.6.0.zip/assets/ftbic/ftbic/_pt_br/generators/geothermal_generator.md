---
navigation:
  title: Gerador Geotérmico
  icon: ftbic:geothermal_generator
  parent: generators/index.md
  position: 2
item_ids:
  - ftbic:geothermal_generator
---

# <Color id="gold">Gerador Geotérmico</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="geothermal_generator" scale="2" />

  Consome **lava** de um tanque interno de 8.000 mB para produzir **<Energy config="machines.geothermal_generator_output" rate="true" />**. O dobro da produção de um Gerador Básico, e totalmente renovável se você tiver uma torneira de portal do Nether ou um lago de lava por perto.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="geothermal_generator" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Alimentando Lava</Color>
</Column>

* Clique com o botão direito no bloco com um balde de lava para encher 1.000 mB.
* Ou canalize lava para dentro com uma <ItemLink id="pump" /> ou qualquer cabo/tubo capaz de transportar fluidos.
* Queima 1 mB de lava por tique enquanto o amortecedor tiver espaço, então um balde rende <Energy config="machines.geothermal_generator_output" times="1000" />.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Estatísticas</Color>
</Column>

* **Nível:** LV
* **Amortecedor interno:** <Energy config="machines.geothermal_generator_capacity" />
* **Tanque:** 8.000 mB
* **Produção:** <Energy config="machines.geothermal_generator_output" rate="true" />
