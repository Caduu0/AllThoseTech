---
navigation:
  title: Gerador Básico
  icon: ftbic:basic_generator
  parent: generators/index.md
  position: 1
item_ids:
  - ftbic:basic_generator
---

# <Color id="gold">Gerador Básico</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="basic_generator" scale="2" />

  Sua primeira fonte de energia: um motorzinho de nível fornalha que queima combustível sólido para produzir **<Energy config="machines.basic_generator_output" rate="true" />**.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>

<RecipeFor id="basic_generator" />

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Estatísticas</Color>
</Column>

* **Nível:** LV (emite <Energy config="machines.basic_generator_output" rate="true" />)
* **Amortecedor interno:** <Energy config="machines.basic_generator_capacity" />
* **Espaço de combustível:** uma pilha

Coloque combustível no único espaço do inventário. O gerador continua queimando até o valor do combustível acabar. Ele **não** para quando o amortecedor está cheio, então conecte-o direto a uma <ItemLink id="lv_battery_box" /> para evitar desperdício.

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Combustíveis Aceitos</Color>
</Column>

Apenas esses combustíveis queimam, e o espaço não aceita mais nada. Outros combustíveis de fornalha, como baldes de lava e varas de blaze, não entram.

* Carvão e carvão vegetal: 1.600 tiques
* Blocos de carvão: 16.000 tiques
* Troncos e tábuas: 300 tiques
* Mudas, gravetos e cana-de-açúcar: 100 tiques
* Cacto: 200 tiques
* <ItemLink id="scrap" />: 400 tiques, um combustível forte para o quão barato é

<RecipesFor id="scrap" />
