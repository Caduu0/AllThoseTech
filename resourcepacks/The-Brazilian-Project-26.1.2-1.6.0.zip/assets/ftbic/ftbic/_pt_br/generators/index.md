---
navigation:
  title: Geradores
  icon: ftbic:basic_generator
  position: 20
---

# <Color id="gold">Geradores</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="basic_generator" scale="2" />

  Quatro geradores renováveis, um gerador de combustão, mais o reator nuclear cobrem todas as etapas da curva de energia do mod.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Comparação de Produção</Color>
</Column>

| Gerador | Nível | Produção | Condições |
|-----------|------|--------|-----------|
| <ItemLink id="basic_generator" /> | LV | <Energy config="machines.basic_generator_output" rate="true" /> | Enquanto o combustível queima |
| <ItemLink id="geothermal_generator" /> | LV | <Energy config="machines.geothermal_generator_output" rate="true" /> | Precisa de lava no tanque |
| <ItemLink id="wind_mill" /> | LV | <ZapMode>0,3 a 6,5 z/t</ZapMode><FEMode><Energy config="machines.wind_mill_min_output" rate="true" /> a <Energy config="machines.wind_mill_max_output" rate="true" /></FEMode> | Depende da altura |
| <ItemLink id="lv_solar_panel" /> | LV | <Energy config="machines.lv_solar_panel_output" rate="true" /> | Luz do dia, acesso ao céu |
| <ItemLink id="mv_solar_panel" /> | MV | <Energy config="machines.mv_solar_panel_output" rate="true" /> | Luz do dia, acesso ao céu |
| <ItemLink id="hv_solar_panel" /> | HV | <Energy config="machines.hv_solar_panel_output" rate="true" /> | Luz do dia, acesso ao céu |
| <ItemLink id="ev_solar_panel" /> | EV | <Energy config="machines.ev_solar_panel_output" rate="true" /> | Luz do dia, acesso ao céu |
| <ItemLink id="nuclear_reactor" /> | até IV | <Energy zaps="1000" rate="true" /> ou mais | Depende do layout |

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Column alignItems="center" fullWidth={true}>
  ## <Color id="gold">Subseções</Color>
</Column>

<SubPages icons={true} />
