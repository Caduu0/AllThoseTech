---
navigation:
  title: Painéis Solares
  icon: ftbic:hv_solar_panel
  parent: generators/index.md
  position: 3
item_ids:
  - ftbic:lv_solar_panel
  - ftbic:mv_solar_panel
  - ftbic:hv_solar_panel
  - ftbic:ev_solar_panel
---

# <Color id="gold">Painéis Solares</Color>

<Column alignItems="center" fullWidth={true}>
  <ItemImage id="hv_solar_panel" scale="2" />

  Painéis solares precisam de **acesso direto ao céu** e de **luz do dia** para gerar. Não produzem nada à noite ou quando cobertos.
</Column>

<ItemImage id="minecraft:air" scale="0.25"/>
***

<Row>
  <ItemImage id="lv_solar_panel" />
  ### <Color id="aqua">Painel Solar LV</Color>
</Row>

<Energy config="machines.lv_solar_panel_output" rate="true" /> durante o dia. Amortecedor: <Energy config="machines.lv_solar_panel_capacity" times="60" />. Energia solar de nível inicial.

<RecipeFor id="lv_solar_panel" />

<ItemImage id="minecraft:air" scale="0.25"/>

<Row>
  <ItemImage id="mv_solar_panel" />
  ### <Color id="aqua">Painel Solar MV</Color>
</Row>

<Energy config="machines.mv_solar_panel_output" rate="true" /> durante o dia. Amortecedor: <Energy config="machines.mv_solar_panel_capacity" times="60" />.

<RecipeFor id="mv_solar_panel" />

<ItemImage id="minecraft:air" scale="0.25"/>

<Row>
  <ItemImage id="hv_solar_panel" />
  ### <Color id="aqua">Painel Solar HV</Color>
</Row>

<Energy config="machines.hv_solar_panel_output" rate="true" /> durante o dia. Amortecedor: <Energy config="machines.hv_solar_panel_capacity" times="60" />.

<RecipeFor id="hv_solar_panel" />

<ItemImage id="minecraft:air" scale="0.25"/>

<Row>
  <ItemImage id="ev_solar_panel" />
  ### <Color id="aqua">Painel Solar EV</Color>
</Row>

<Energy config="machines.ev_solar_panel_output" rate="true" /> durante o dia. Amortecedor: <Energy config="machines.ev_solar_panel_capacity" times="60" />. A maior produção solar do mod.

<RecipeFor id="ev_solar_panel" />
